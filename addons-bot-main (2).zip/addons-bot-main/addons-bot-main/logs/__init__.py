# logs/__init__.py

"""
Logging package for bot logging functionality.
"""
async def setup(bot):
    pass  # Nessuna azione specifica richiesta per questo pacchetto