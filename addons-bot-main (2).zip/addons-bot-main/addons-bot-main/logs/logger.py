# logs/logger.py

import logging
import os
from datetime import datetime
from logging.handlers import RotatingFileHandler
import discord

class BotLogger:
    """
    Logger class for the Discord bot.
    Provides methods to log events, commands, errors, and audit actions.
    """
    
    def __init__(self, logs_dir="/app/data/logs"):
        """
        Initialize the logger with appropriate handlers and formatters.
        
        Args:
            logs_dir: Directory where log files will be stored
        """
        self.logs_dir = logs_dir
        
        # Ensure logs directory exists
        os.makedirs(logs_dir, exist_ok=True)
        
        # Configure main logger
        self.logger = logging.getLogger('discord_bot')
        self.logger.setLevel(logging.INFO)
        
        # Remove existing handlers if any (to prevent duplicates)
        if self.logger.handlers:
            self.logger.handlers.clear()
        
        # Create formatters
        console_format = logging.Formatter(
            '%(asctime)s [%(levelname)s] %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        file_format = logging.Formatter(
            '%(asctime)s [%(levelname)s] [%(name)s] %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # Console handler
        console_handler = logging.StreamHandler()
        console_handler.setLevel(logging.INFO)
        console_handler.setFormatter(console_format)
        self.logger.addHandler(console_handler)
        
        # File handlers with rotation (10MB max size, 5 backup files)
        # Main log file
        main_handler = RotatingFileHandler(
            os.path.join(logs_dir, 'bot.log'),
            maxBytes=10*1024*1024,  # 10MB
            backupCount=5,
            encoding='utf-8'
        )
        main_handler.setLevel(logging.INFO)
        main_handler.setFormatter(file_format)
        self.logger.addHandler(main_handler)
        
        # Error log file
        error_handler = RotatingFileHandler(
            os.path.join(logs_dir, 'error.log'),
            maxBytes=10*1024*1024,
            backupCount=5,
            encoding='utf-8'
        )
        error_handler.setLevel(logging.ERROR)
        error_handler.setFormatter(file_format)
        self.logger.addHandler(error_handler)
        
        # Create specific loggers
        self.command_logger = self._create_specific_logger('command', 'command.log')
        self.event_logger = self._create_specific_logger('event', 'event.log')
        self.audit_logger = self._create_specific_logger('audit', 'audit.log')
    
    def _create_specific_logger(self, name, filename):
        """
        Create a specific logger with its own file.
        
        Args:
            name: Logger name
            filename: Log file name
            
        Returns:
            Logger instance
        """
        logger = logging.getLogger(f'discord_bot.{name}')
        logger.setLevel(logging.INFO)
        
        # Remove existing handlers if any
        if logger.handlers:
            logger.handlers.clear()
        
        # Set propagation to False to avoid duplicate logs in parent logger
        logger.propagate = False
        
        # Create formatter
        formatter = logging.Formatter(
            '%(asctime)s [%(levelname)s] %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        # Create file handler
        handler = RotatingFileHandler(
            os.path.join(self.logs_dir, filename),
            maxBytes=10*1024*1024,
            backupCount=5,
            encoding='utf-8'
        )
        handler.setFormatter(formatter)
        logger.addHandler(handler)
        
        return logger
    
    def info(self, message):
        """Log an informational message."""
        self.logger.info(message)
    
    def warning(self, message):
        """Log a warning message."""
        self.logger.warning(message)
    
    def error(self, message, exc_info=False):
        """Log an error message."""
        self.logger.error(message, exc_info=exc_info)
    
    def critical(self, message, exc_info=True):
        """Log a critical error message."""
        self.logger.critical(message, exc_info=exc_info)
    
    def command(self, ctx, command_name, success=True):
        """
        Log a command execution.
        
        Args:
            ctx: Command context
            command_name: Name of the command
            success: Whether the command executed successfully
        """
        status = "SUCCESS" if success else "FAILED"
        message = (
            f"{status} | {command_name} | "
            f"User: {ctx.author} ({ctx.author.id}) | "
            f"Guild: {ctx.guild.name if ctx.guild else 'DM'} | "
            f"Channel: {ctx.channel.name if hasattr(ctx.channel, 'name') else 'Unknown'}"
        )
        self.command_logger.info(message)
    
    def event(self, event_name, details):
        """
        Log a Discord event.
        
        Args:
            event_name: Name of the event
            details: Details about the event
        """
        self.event_logger.info(f"{event_name} | {details}")
    
    def audit(self, user, action, target=None, details=None):
        """
        Log an administrative action.
        
        Args:
            user: User who performed the action
            action: Action performed
            target: Target of the action (optional)
            details: Additional details (optional)
        """
        user_str = f"{user} ({user.id})" if isinstance(user, (discord.Member, discord.User)) else str(user)
        target_str = f"{target} ({target.id})" if isinstance(target, (discord.Member, discord.User)) else str(target) if target else "N/A"
        details_str = str(details) if details else "N/A"
        
        self.audit_logger.info(f"{action} | User: {user_str} | Target: {target_str} | Details: {details_str}")
    
    def setup_discord_logger(self):
        """Configure the Discord.py logger."""
        discord_logger = logging.getLogger('discord')
        discord_logger.setLevel(logging.WARNING)
        
        handler = RotatingFileHandler(
            os.path.join(self.logs_dir, 'discord.log'),
            maxBytes=10*1024*1024,
            backupCount=3,
            encoding='utf-8'
        )
        
        formatter = logging.Formatter(
            '%(asctime)s [%(levelname)s] %(name)s: %(message)s',
            datefmt='%Y-%m-%d %H:%M:%S'
        )
        
        handler.setFormatter(formatter)
        discord_logger.addHandler(handler)
