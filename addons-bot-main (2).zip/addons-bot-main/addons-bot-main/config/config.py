# config/config.py

import json
import os
from typing import Any, Dict, Optional, Union

class Config:
    """
    Centralized configuration system for the bot.
    Manages loading, accessing, and updating configurations.
    """
    
    def __init__(self, config_path: str = "config/default_config.json"):
        """
        Initialize the configuration system.
        
        Args:
            config_path: Path to the JSON configuration file
        """
        self.config_path = config_path
        self.config_data = {}
        self.load_config()
    
    def load_config(self) -> None:
        """Load configuration from JSON file."""
        try:
            if os.path.exists(self.config_path):
                with open(self.config_path, 'r', encoding='utf-8') as f:
                    self.config_data = json.load(f)
            else:
                # Create file with empty configuration if it doesn't exist
                self.config_data = {}
                self.save_config()
                print(f"Configuration file created at {self.config_path}")
        except Exception as e:
            print(f"Error loading configuration: {e}")
            self.config_data = {}
    
    def save_config(self) -> None:
        """Save current configuration to JSON file."""
        try:
            # Ensure directory exists
            os.makedirs(os.path.dirname(self.config_path), exist_ok=True)
            
            with open(self.config_path, 'w', encoding='utf-8') as f:
                json.dump(self.config_data, f, indent=4)
        except Exception as e:
            print(f"Error saving configuration: {e}")
    
    def get(self, key: str, default: Any = None) -> Any:
        """
        Get a value from the configuration.
        
        Args:
            key: Key of the value to get
            default: Default value if the key doesn't exist
            
        Returns:
            The value associated with the key or the default value
        """
        keys = key.split('.')
        data = self.config_data
        
        for k in keys:
            if isinstance(data, dict) and k in data:
                data = data[k]
            else:
                return default
        
        return data
    
    def set(self, key: str, value: Any) -> None:
        """
        Set a value in the configuration.
        
        Args:
            key: Key of the value to set
            value: Value to set
        """
        keys = key.split('.')
        data = self.config_data
        
        # Navigate through nested keys up to the second-to-last
        for i, k in enumerate(keys[:-1]):
            if k not in data:
                data[k] = {}
            elif not isinstance(data[k], dict):
                # If the path exists but isn't a dictionary, overwrite it
                data[k] = {}
            data = data[k]
        
        # Set the value at the last key
        data[keys[-1]] = value
        self.save_config()
    
    def update(self, new_config: Dict[str, Any]) -> None:
        """
        Update multiple values in the configuration at once.
        
        Args:
            new_config: Dictionary with new configurations
        """
        def update_dict(target, source):
            for key, value in source.items():
                if isinstance(value, dict) and key in target and isinstance(target[key], dict):
                    update_dict(target[key], value)
                else:
                    target[key] = value
        
        update_dict(self.config_data, new_config)
        self.save_config()