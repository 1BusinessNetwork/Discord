# config/__init__.py

"""
Configuration package for bot settings.
"""
async def setup(bot):
    pass  # Nessuna azione specifica richiesta per questo pacchetto