# data/__init__.py

"""
Data package for storing persistent bot data.
"""
async def setup(bot):
    pass  # Nessuna azione specifica richiesta per questo pacchetto