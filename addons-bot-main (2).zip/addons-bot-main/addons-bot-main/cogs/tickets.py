# cogs/tickets.py

import discord
import re
import asyncio
from discord.ext import commands
from typing import Optional, Dict, List, Any, Union
import datetime

class TicketCog(commands.Cog):
    """
    Cog for handling the ticket system functionality.
    Provides commands for creating and managing support tickets.
    """
    
    def __init__(self, bot):
        """Initialize the TicketCog."""
        self.bot = bot
        self._load_views()
    
    def _load_views(self):
        """Load and register persistent UI views for tickets."""
        # Import views here to avoid circular imports
        from views.ticket_views import (
            TicketCloseButton,
            TicketReopenDeleteView,
            TicketPanelView
        )
        
        # Add persistent views
        self.bot.add_view(TicketCloseButton())
        self.bot.add_view(TicketReopenDeleteView())
        self.bot.add_view(TicketPanelView())
    
    @commands.command(name="delete_ticket")
    async def delete_ticket(self, ctx):
        """
        Delete a ticket.
        Only works in ticket channels.
        """
        # Check if channel is a ticket
        if not ctx.channel.topic or "ticket" not in ctx.channel.topic.lower():
            await ctx.send(f"{ctx.author.mention}, This channel is not a ticket.")
            return
        
        # Create delete confirmation view
        view = self._create_delete_confirmation_view()
        
        # Ask for confirmation
        confirm_embed = discord.Embed(
            description=f"{ctx.author.mention}, Are you sure you want to delete this ticket? This action cannot be undone.",
            color=discord.Color.gold()
        )
        await ctx.send(embed=confirm_embed, view=view)
    
    @commands.command(name="add_user")
    async def add_user(self, ctx, user: discord.Member):
        """
        Add a user to the ticket.
        Only works in ticket channels.
        
        Args:
            user: The user to add to the ticket
        """
        # Check if channel is a ticket
        if not ctx.channel.topic or "ticket" not in ctx.channel.topic.lower():
            await ctx.send(f"{ctx.author.mention}, This channel is not a ticket.")
            return
        
        # Add user to the ticket
        await ctx.channel.set_permissions(
            user,
            read_messages=True,
            send_messages=True,
            read_message_history=True,
            attach_files=True,
            add_reactions=True
        )
        
        # Send notification
        embed = discord.Embed(
            description=f"{user.mention} has been added to the ticket by {ctx.author.mention}",
            color=discord.Color.green()
        )
        await ctx.send(embed=embed)
    
    @commands.command(name="create_ticket")
    @commands.has_permissions(administrator=True)
    async def create_ticket_command(self, ctx, *users: Union[discord.Member, int]):
        """
        Create a general ticket and add multiple users to it.
        
        Args:
            users: One or more users to add to the ticket (mentions or IDs)
        """
        if not users:
            await ctx.send("Please specify at least one user (mention or ID).")
            return
        
        # Process user inputs into valid members
        valid_users = []
        for user_input in users:
            # Handle user IDs
            if isinstance(user_input, int):
                try:
                    user = await self.bot.fetch_user(user_input)
                    member = ctx.guild.get_member(user.id)
                    if not member:
                        await ctx.send(f"User with ID {user_input} is not a member of this server.")
                        continue
                    valid_users.append(member)
                except discord.NotFound:
                    await ctx.send(f"User with ID {user_input} not found.")
                    continue
            else:
                valid_users.append(user_input)
        
        if not valid_users:
            await ctx.send("No valid users found.")
            return
        
        # Get category for general tickets
        category_id = self.bot.config.get("tickets.general_category_id")
        if not category_id:
            await ctx.send("General ticket category not configured! Please check the bot configuration.")
            return
        
        category = ctx.guild.get_channel(category_id)
        if not category:
            await ctx.send("General ticket category not found! Please check the bot configuration.")
            return
        
        # Get staff role for permissions
        staff_role_id = self.bot.config.get("server.staff_role_id")
        staff_role = ctx.guild.get_role(staff_role_id)
        
        if not staff_role:
            await ctx.send("Staff role not found! Please check the bot configuration.")
            return
        
        # Set up channel permissions
        overwrites = {
            ctx.guild.default_role: discord.PermissionOverwrite(view_channel=False),
            staff_role: discord.PermissionOverwrite(
                view_channel=True,
                send_messages=True,
                read_message_history=True,
                attach_files=True,
                add_reactions=True
            )
        }
        
        # Add permissions for all users
        for user in valid_users:
            overwrites[user] = discord.PermissionOverwrite(
                view_channel=True,
                send_messages=True,
                read_message_history=True,
                attach_files=True,
                add_reactions=True
            )
        
        # Create the ticket channel - main user is the first one
        main_user = valid_users[0]
        users_mentions = " ".join([user.mention for user in valid_users])
        
        try:
            sanitized_name = re.sub(r'[^a-zA-Z0-9 ]', '', main_user.name).lower()
            if len(valid_users) > 1:
                channel_name = f"{sanitized_name}-group-ticket"
            else:
                channel_name = f"{sanitized_name}-ticket"
            
            # Create the channel
            ticket_channel = await ctx.guild.create_text_channel(
                name=channel_name[:100],  # Discord has a limit on channel name length
                category=category,
                topic=f"ticket-{main_user.mention}-general | Additional Users: {users_mentions}",
                overwrites=overwrites
            )
            
            # Create ticket details with note about admin creation
            details = {
                "Created By": f"{ctx.author.mention} (Staff)",
                "Users": users_mentions,
                "Message": f"This ticket was created by {ctx.author.mention} for multiple users."
            }
            
            # Create the ticket embed
            embed = self.bot.embed_builder.ticket_embed("general", main_user, details)
            
            # Send the welcome message
            from views.ticket_views import TicketCloseButton
            await ticket_channel.send(
                f"{users_mentions}, Welcome! A staff member has created this ticket for you.",
                embed=embed,
                view=TicketCloseButton()
            )
            
            # Log the ticket creation
            self.bot.logger.info(
                f"Group ticket created for {len(valid_users)} users by {ctx.author} ({ctx.author.id}) - "
                f"Channel: {ticket_channel.name} ({ticket_channel.id})"
            )
            
            # Confirmation message
            embed = discord.Embed(
                title="✅ Ticket Created",
                description=f"Successfully created ticket {ticket_channel.mention} for the following users:\n" + 
                            "\n".join([f"• {user.mention}" for user in valid_users]),
                color=self.bot.config.get("server.color_theme")
            )
            await ctx.send(embed=embed)
            
        except Exception as e:
            self.bot.logger.error(f"Error creating group ticket: {e}")
            await ctx.send(f"An error occurred creating the ticket: {str(e)}")
    
    @commands.command(name="contact_panel", aliases=["rcontact_panel"])
    @commands.has_permissions(administrator=True)
    async def contact_panel(self, ctx):
        """Create a contact panel in the current channel."""
        # Create an embed for the ticket panel
        embed = discord.Embed(
            description=(
                "### Click the Button to Contact Us.\n\n"
                "> Open a contact channel, then describe your goals and desires in your custom channel.\n\n"
                "- Visit our websites:\n"
                "https://reelsbuilder.ai/\n"
                "https://reelsbuilder.site/\n\n"
                "- Follow our Socials:\n"
                "https://linktr.ee/reelsbuilder\n"
            ),
            color=self.bot.config.get("server.color_theme")
        )
        
        # Set footer
        embed.set_footer(text="We look forward to assisting you!")
        
        # Add thumbnail
        embed.set_thumbnail(url="https://media.discordapp.net/attachments/1347896851130744852/1349081976946167860/ReelsBuilderLogoPNG.png")
        
        # Add image
        embed.set_image(url=self.bot.config.get("tickets.panel_image"))
        
        # Create view with ticket creation button
        from views.ticket_views import TicketPanelView
        view = TicketPanelView()
        
        # Add website link button
        view.add_item(discord.ui.Button(
            label="Website",
            url="https://reelsbuilder.ai",
            style=discord.ButtonStyle.link
        ))
        
        # Send the panel
        await ctx.send(embed=embed, view=view)
        
        # Delete the command message
        try:
            await ctx.message.delete()
        except discord.HTTPException:
            pass
    
    async def _get_ticket_owner(self, channel: discord.TextChannel) -> Optional[discord.Member]:
        """Extract ticket owner from channel topic."""
        if not channel.topic:
            return None
        
        matches = re.findall(r"<@!?(\d+)>", channel.topic)
        if not matches:
            return None
        
        try:
            user_id = int(matches[0])
            return channel.guild.get_member(user_id)
        except (ValueError, IndexError):
            return None
    
    def _create_delete_confirmation_view(self):
        """Create a view for confirming ticket deletion."""
        class DeleteConfirmationView(discord.ui.View):
            def __init__(self, cog):
                super().__init__(timeout=60)
                self.cog = cog
            
            @discord.ui.button(label="Confirm", style=discord.ButtonStyle.danger)
            async def confirm_button(self, interaction: discord.Interaction, button: discord.ui.Button):
                # Log the deletion
                await interaction.channel.send(
                    embed=discord.Embed(
                        description=f"Ticket was deleted by: {interaction.user.mention} | {interaction.user.id} | {interaction.user.name}"
                    )
                )
                
                # Create transcript
                await self.cog.bot.transcript_manager.log_transcript(
                    interaction.channel,
                    deleted_by=interaction.user
                )
                
                # Delete the channel
                await interaction.response.send_message("Deleting ticket...", ephemeral=True)
                await asyncio.sleep(2)  # Brief delay to ensure message is sent
                await interaction.channel.delete()
            
            @discord.ui.button(label="Cancel", style=discord.ButtonStyle.gray)
            async def cancel_button(self, interaction: discord.Interaction, button: discord.ui.Button):
                await interaction.response.edit_message(
                    content="Ticket deletion cancelled.",
                    view=None
                )
        
        return DeleteConfirmationView(self)

    @commands.Cog.listener()
    async def on_member_remove(self, member):
        """Handle when a user leaves the server with open tickets."""
        for channel in member.guild.text_channels:
            if not channel.topic:
                continue
                
            if member.mention in channel.topic and "ticket" in channel.topic.lower():
                # User had a ticket open
                embed = discord.Embed(
                    description=f"> {member.mention} has left the server",
                    color=discord.Color.red()
                )
                
                # Import view to prevent circular imports
                from views.ticket_views import TicketReopenDeleteView
                
                await channel.send(embed=embed, view=TicketReopenDeleteView())
                
                # Log the ticket
                await self.bot.transcript_manager.log_transcript(channel=channel)
                
                # Delete onboarding tickets automatically
                if "onboard" in channel.topic.lower():
                    await channel.delete()

async def setup(bot):
    """Add the cog to the bot."""
    await bot.add_cog(TicketCog(bot))
