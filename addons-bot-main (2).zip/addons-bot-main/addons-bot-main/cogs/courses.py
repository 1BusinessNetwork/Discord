# cogs/courses.py

import discord
import json
import os
import asyncio
import logging
import re
from discord.ext import commands, tasks
from typing import Dict, List, Any, Optional, Union
from views.course_views import CourseModuleView, LessonSelect

class CoursesCog(commands.Cog):
    """
    Cog for managing course/module content.
    Uses a file-based approach for course configuration and management with VIP/Free access control.
    """
    
    def __init__(self, bot):
        """Initialize the CoursesCog."""
        self.bot = bot
        self.courses_dir = "data/courses"
        self.courses_file = f"{self.courses_dir}/courses.json"
        self.courses_data = {}
        self._load_views()
        self.load_courses_data()
        self.file_watcher.start()
    
    def cog_unload(self):
        """Clean up when the cog is unloaded."""
        self.file_watcher.cancel()
    
    def _load_views(self):
        """Load and register persistent UI views for courses."""
        self.bot.add_view(CourseModuleView())
    
    def load_courses_data(self) -> bool:
        """
        Load courses data from JSON file.
        
        Returns:
            bool: True if loaded successfully, False otherwise
        """
        try:
            # Ensure courses directory exists
            os.makedirs(self.courses_dir, exist_ok=True)
            
            # Create default file if it doesn't exist
            if not os.path.exists(self.courses_file):
                default_data = {
                    "modules": [],
                    "lessons": {},
                    "free_lessons": {},  # Map module numbers to allowed free lesson numbers
                    "vip_role_id": None  # Role ID for VIP members
                }
                with open(self.courses_file, "w", encoding="utf-8") as f:
                    json.dump(default_data, f, indent=2)
                self.courses_data = default_data
                return True
            
            # Load existing file
            with open(self.courses_file, "r", encoding="utf-8") as f:
                self.courses_data = json.load(f)
            
            # Process the loaded data to ensure the correct format
            self._process_course_data()
            
            self.bot.logger.info(f"Loaded courses data: {len(self.courses_data.get('modules', []))} modules")
            return True
        except Exception as e:
            self.bot.logger.error(f"Error loading courses data: {e}")
            return False
    
    def _process_course_data(self):
        """Process the loaded course data to ensure it's in the correct format."""
        # Ensure required keys exist
        if "modules" not in self.courses_data:
            self.courses_data["modules"] = []
        
        if "lessons" not in self.courses_data:
            self.courses_data["lessons"] = {}
        
        if "free_lessons" not in self.courses_data:
            self.courses_data["free_lessons"] = {}
        
        if "vip_role_id" not in self.courses_data:
            self.courses_data["vip_role_id"] = None
            
        # Process modules to normalize data
        for module in self.courses_data.get("modules", []):
            # Ensure module has required fields
            if "module_number" not in module:
                module["module_number"] = 1
            
            if "title" not in module:
                module["title"] = f"Module {module['module_number']}"
            
            # Process lessons if they are embedded in the module
            if "lessons" in module:
                for lesson in module["lessons"]:
                    # Create a unique key for this lesson
                    lesson_key = f"{module['module_number']:02d}{lesson.get('lesson_number', 1):02d}"
                    
                    # Add to the lessons dictionary
                    self.courses_data["lessons"][lesson_key] = {
                        "title": lesson.get("title", f"Lesson {lesson.get('lesson_number', 1)}"),
                        "content": lesson.get("content", "No content available."),
                        "video_url": lesson.get("video_url")
                    }
                    
                    # Set default free lesson as only the first lesson if not defined
                    module_str = str(module['module_number'])
                    if module_str not in self.courses_data["free_lessons"]:
                        self.courses_data["free_lessons"][module_str] = [1]
    
    def save_courses_data(self) -> bool:
        """
        Save courses data to JSON file.
        
        Returns:
            bool: True if saved successfully, False otherwise
        """
        try:
            os.makedirs(self.courses_dir, exist_ok=True)
            
            with open(self.courses_file, "w", encoding="utf-8") as f:
                json.dump(self.courses_data, f, indent=2)
            
            self.bot.logger.info("Saved courses data")
            return True
        except Exception as e:
            self.bot.logger.error(f"Error saving courses data: {e}")
            return False
    
    @tasks.loop(seconds=60)
    async def file_watcher(self):
        """Watch for changes in the courses.json file and reload if modified."""
        try:
            if os.path.exists(self.courses_file):
                # Get file's modification time
                mod_time = os.path.getmtime(self.courses_file)
                
                # Store as attribute if not already set
                if not hasattr(self, "last_mod_time"):
                    self.last_mod_time = mod_time
                    return
                
                # Check if file was modified
                if mod_time > self.last_mod_time:
                    self.bot.logger.info("Courses file modified, reloading...")
                    self.load_courses_data()
                    self.last_mod_time = mod_time
        except Exception as e:
            self.bot.logger.error(f"Error in file watcher: {e}")
    
    @file_watcher.before_loop
    async def before_file_watcher(self):
        """Wait until the bot is ready before starting the task."""
        await self.bot.wait_until_ready()
    
    def is_vip_user(self, user: discord.Member) -> bool:
        """
        Check if a user has VIP access to courses.
        
        Args:
            user: The discord member to check
            
        Returns:
            bool: True if the user has VIP access, False otherwise
        """
        vip_role_id = self.courses_data.get("vip_role_id")
        if not vip_role_id:
            return False  # No VIP role configured
            
        vip_role = user.guild.get_role(vip_role_id)
        if not vip_role:
            return False  # Role doesn't exist
            
        return vip_role in user.roles
    
    def get_available_lessons(self, module_number: int, user: discord.Member) -> List[int]:
        """
        Get the list of lesson numbers available to a user for a specific module.
        
        Args:
            module_number: The module number
            user: The discord member
            
        Returns:
            List[int]: List of available lesson numbers
        """
        module_str = str(module_number)
        
        # If the user is VIP, they can access all lessons
        if self.is_vip_user(user):
            # Get all lessons for this module
            all_lessons = []
            for lesson_key in self.courses_data.get("lessons", {}):
                if lesson_key.startswith(f"{module_number:02d}"):
                    lesson_num = int(lesson_key[2:])
                    all_lessons.append(lesson_num)
            return sorted(all_lessons)
        
        # Otherwise, return only free lessons
        return sorted(self.courses_data.get("free_lessons", {}).get(module_str, [1]))
    
    @commands.command(name="course_preview")
    @commands.has_permissions(administrator=True)
    async def course_preview(self, ctx, module_number: int):
        """
        Preview a course module.
        
        Args:
            module_number: The module number to preview
        """
        # Find the module
        module = None
        for m in self.courses_data.get("modules", []):
            if m.get("module_number") == module_number:
                module = m
                break
        
        if not module:
            await ctx.send(f"Module {module_number} not found!")
            return
        
        # Create embed
        embed = discord.Embed(
            title=f"Module {module_number}: {module.get('title', '')}",
            description=module.get("description", ""),
            color=self.bot.config.get("server.color_theme")
        )
        
        # Add image if available
        if "image_url" in module and module["image_url"]:
            embed.set_image(url=module["image_url"])
        
        # Add module number in footer for reference
        embed.set_footer(text=f"module {module_number}")
        
        # Create view
        view = CourseModuleView()
        
        # Send module preview
        await ctx.send(embed=embed, view=view)
    
    @commands.command(name="module1")
    @commands.has_permissions(administrator=True)
    async def module_command(self, ctx, module_number: int):
        """
        Create a course module in the current channel.
        
        Args:
            module_number: The module number to create
        """
        # Find the module
        module = None
        for m in self.courses_data.get("modules", []):
            if m.get("module_number") == module_number:
                module = m
                break
        
        if not module:
            await ctx.send(f"Module {module_number} not found in configuration!")
            return
        
        # Create the embed
        embed = discord.Embed(
            title=f"Module {module_number}",
            description=module.get("title", ""),
            color=self.bot.config.get("server.color_theme")
        )
        
        # Add footer with module number for reference
        embed.set_footer(text=f"module {module_number}")
        
        # Create view with course button
        view = CourseButton(self.bot, self)
        
        # Send the module message
        await ctx.send(embed=embed, view=view)
        
        # Delete command message
        try:
            await ctx.message.delete()
        except discord.HTTPException:
            pass
    
    @commands.command(name="publish_courses")
    @commands.has_permissions(administrator=True)
    async def publish_courses(self, ctx, channel_id: Optional[int] = None):
        """
        Publish all configured courses to a channel.
        
        Args:
            channel_id: Optional channel ID to publish to (defaults to current channel)
        """
        # Get target channel
        channel = None
        if channel_id:
            channel = self.bot.get_channel(channel_id)
        else:
            channel = ctx.channel
        
        if not channel:
            await ctx.send("Target channel not found!")
            return
        
        # Check if we have modules to publish
        modules = self.courses_data.get("modules", [])
        if not modules:
            await ctx.send("No modules found to publish!")
            return
        
        # Publish each module
        count = 0
        for module in modules:
            # Create embed
            embed = discord.Embed(
                title=f"Module {module.get('module_number')}",
                description=module.get("title", ""),
                color=self.bot.config.get("server.color_theme")
            )
            
            # Add image if available
            if "image_url" in module and module["image_url"]:
                embed.set_image(url=module["image_url"])
            
            # Add module number in footer for reference
            embed.set_footer(text=f"module {module.get('module_number')}")
            
            # Create view
            view = CourseButton(self.bot, self)
            
            # Send module
            await channel.send(embed=embed, view=view)
            count += 1
            
            # Add a small delay to avoid rate limits
            await asyncio.sleep(1)
        
        await ctx.send(f"Published {count} modules to {channel.mention}")
    
    @commands.command(name="set_vip_role")
    @commands.has_permissions(administrator=True)
    async def set_vip_role(self, ctx, role: discord.Role):
        """
        Set the VIP role for course access.
        
        Args:
            role: The role to set as VIP
        """
        self.courses_data["vip_role_id"] = role.id
        self.save_courses_data()
        
        await ctx.send(f"VIP role has been set to {role.mention}. Users with this role will have access to all lessons.")
    
    @commands.command(name="set_free_lessons")
    @commands.has_permissions(administrator=True)
    async def set_free_lessons(self, ctx, module_number: int, *lesson_numbers: int):
        """
        Set which lessons in a module are free.
        
        Args:
            module_number: The module number
            lesson_numbers: Variable number of lesson numbers that should be free
        """
        if not lesson_numbers:
            await ctx.send("Please specify at least one lesson number to set as free.")
            return
        
        # Update free lessons in the config
        module_str = str(module_number)
        self.courses_data["free_lessons"][module_str] = sorted(list(lesson_numbers))
        self.save_courses_data()
        
        lessons_str = ", ".join(str(num) for num in sorted(lesson_numbers))
        await ctx.send(f"Free lessons for Module {module_number} have been set to: {lessons_str}")
    
    @commands.command(name="reload_courses")
    @commands.has_permissions(administrator=True)
    async def reload_courses(self, ctx):
        """Force reload courses from the configuration file."""
        success = self.load_courses_data()
        if success:
            await ctx.send("✅ Courses data reloaded successfully.")
        else:
            await ctx.send("❌ Failed to reload courses data. Check the logs for details.")


class CourseButton(discord.ui.View):
    """View with a button to access module lessons."""
    
    def __init__(self, bot, cog):
        super().__init__(timeout=None)
        self.bot = bot
        self.cog = cog
    
    @discord.ui.button(label="Click me", style=discord.ButtonStyle.grey, custom_id="bullmarketbutton")
    async def interaction_bull_course(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.defer(ephemeral=True)
        
        # Extract module number from message
        embed = interaction.message.embeds[0]
        footer = str(embed.footer.text)
        
        # Parse module number from footer text
        module_match = re.search(r"module\s+(\d+)", footer.lower())
        if not module_match:
            await interaction.followup.send("Could not determine module number!", ephemeral=True)
            return
        
        module_number = int(module_match.group(1))
        
        # Get available lessons for this user
        available_lessons = self.cog.get_available_lessons(module_number, interaction.user)
        
        # Create options for the select menu
        options = []
        for lesson_key, lesson_data in self.cog.courses_data.get("lessons", {}).items():
            if lesson_key.startswith(f"{module_number:02d}"):
                lesson_number = int(lesson_key[2:])
                
                # Add a 🔒 emoji for locked lessons
                locked = lesson_number not in available_lessons
                emoji = "🔒" if locked else f"{lesson_number}️⃣"
                
                # Create description with lock indication
                description = lesson_data.get("title", f"Lesson {lesson_number}")
                if locked:
                    description += " (VIP Only)"
                
                options.append(
                    discord.SelectOption(
                        label=f"Lesson {lesson_number}",
                        emoji=emoji,
                        value=lesson_key,
                        description=description,
                        default=False
                    )
                )
        
        # If no lessons are found, notify the user
        if not options:
            await interaction.followup.send("No lessons found for this module!", ephemeral=True)
            return
        
        # Sort options by lesson number
        options.sort(key=lambda x: int(x.value[2:]))
        
        # Create the select menu
        select = discord.ui.Select(options=options)
        
        async def on_select(select_interaction: discord.Interaction):
            lesson_key = select.values[0]
            lesson_number = int(lesson_key[2:])
            
            # Check if user has access to this lesson
            if lesson_number not in available_lessons:
                await select_interaction.response.send_message(
                    "⚠️ This lesson is only available to VIP members. "
                    "Please upgrade your membership to access this content.",
                    ephemeral=True
                )
                return
            
            # Get lesson data
            lesson_data = self.cog.courses_data.get("lessons", {}).get(lesson_key)
            
            if not lesson_data:
                await select_interaction.response.send_message("Lesson not found!", ephemeral=True)
                return
            
            # If there's a video URL, send it
            if lesson_data.get("video_url"):
                await select_interaction.response.send_message(
                    lesson_data["video_url"],
                    ephemeral=True
                )
            else:
                # Otherwise send lesson content
                await select_interaction.response.send_message(
                    lesson_data.get("content", "No content available."),
                    ephemeral=True
                )
        
        select.callback = on_select
        
        # Create a view with the select menu
        course_view = discord.ui.View(timeout=None)
        course_view.add_item(select)
        
        # Send the view
        await interaction.followup.send(
            content="Please select a lesson to view:",
            view=course_view,
            ephemeral=True
        )


async def setup(bot):
    """Add the cog to the bot."""
    await bot.add_cog(CoursesCog(bot))
