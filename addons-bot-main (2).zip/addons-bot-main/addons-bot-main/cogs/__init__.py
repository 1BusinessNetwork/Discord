# cogs/__init__.py

"""
Cogs package containing all bot command modules.
"""
async def setup(bot):
    pass  # Nessuna azione specifica richiesta per questo pacchetto