# cogs/coupon.py

import discord
import re
from discord.ext import commands
from discord import app_commands
from typing import Optional
from discord.ui import Modal, TextInput

# Context menus MUST be definiti fuori dalla classe
@app_commands.context_menu(name="Send Coupon")
async def send_coupon_context(interaction: discord.Interaction, user: discord.User):
    """Context menu command for sending a coupon code."""
    # Check permissions
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message(
            "You do not have permission to use this command.",
            ephemeral=True
        )
        return
    
    # Create and show modal
    modal = CouponModal()
    modal.user_id = user.id
    await interaction.response.send_modal(modal)

@app_commands.context_menu(name="Send Coupon Message")
async def send_coupon_message_context(interaction: discord.Interaction, message: discord.Message):
    """Context menu command for sending a coupon code based on a message."""
    # Check permissions
    if not interaction.user.guild_permissions.administrator:
        await interaction.response.send_message(
            "You do not have permission to use this command.",
            ephemeral=True
        )
        return
    
    # Create and show modal
    modal = CouponModal()
    modal.user_id = message.author.id
    await interaction.response.send_modal(modal)

# Modal definito fuori dalla classe
class CouponModal(Modal):
    """Modal for entering coupon code."""
    
    def __init__(self):
        super().__init__(title="Coupon")
        
        self.coupon = TextInput(
            label="Enter Coupon Code",
            placeholder="Please enter your code here",
            required=True
        )
        
        self.add_item(self.coupon)
        self.user_id = None
    
    async def on_submit(self, interaction: discord.Interaction):
        """Handle modal submission."""
        try:
            # Get the target user
            user = await interaction.client.fetch_user(self.user_id)
            
            # Create embed for DM
            embed = discord.Embed(
                title="Here is your Coupon Code!",
                description=f"Dear {user.name}, here is your coupon code for the server **{interaction.guild.name}**:",
                color=discord.Color.green()
            )
            
            embed.add_field(name="Coupon Code", value=self.coupon.value, inline=True)
            embed.set_footer(text="Use this code at checkout!")
            
            # Send DM to user
            await user.send(embed=embed)
            
            # Confirm to the admin
            await interaction.response.send_message(
                "✅ Coupon code sent successfully.",
                ephemeral=True
            )
            
            # Log the action
            interaction.client.logger.info(
                f"Coupon code sent to {user} by {interaction.user}"
            )
            
        except discord.Forbidden:
            await interaction.response.send_message(
                f"❌ Failed to message {user.mention} as they've disabled Direct Messages.",
                ephemeral=True
            )
        except Exception as e:
            await interaction.response.send_message(
                f"❌ An error occurred: {str(e)}",
                ephemeral=True
            )

class CouponCog(commands.Cog):
    """
    Cog for handling coupon functionality.
    Provides commands for sending coupon codes to users.
    """
    
    def __init__(self, bot):
        """Initialize the CouponCog."""
        self.bot = bot
    
    @app_commands.command(
        name="coupon",
        description="Send a coupon code to a user through DM"
    )
    @app_commands.describe(
        user="User to send the coupon to",
        code="Coupon code to send"
    )
    @app_commands.default_permissions(administrator=True)
    async def coupon_slash(
        self,
        interaction: discord.Interaction,
        user: discord.User,
        code: str
    ):
        """Slash command to send a coupon code to a user."""
        try:
            # Create embed for DM
            embed = discord.Embed(
                title="Here is your Coupon Code!",
                description=f"Dear {user.name}, here is your coupon code for the server **{interaction.guild.name}**:",
                color=discord.Color.green()
            )
            
            embed.add_field(name="Coupon Code", value=code, inline=True)
            embed.set_footer(text="Use this code at checkout!")
            
            # Send DM to user
            await user.send(embed=embed)
            
            # Confirm to the admin
            await interaction.response.send_message(
                f"✅ Coupon code sent to {user.mention}.",
                ephemeral=True
            )
            
            # Log the action
            self.bot.logger.info(
                f"Coupon code sent to {user} by {interaction.user}"
            )
            
        except discord.Forbidden:
            await interaction.response.send_message(
                f"❌ Failed to send coupon to {user.mention}. They may have DMs disabled.",
                ephemeral=True
            )
        except Exception as e:
            await interaction.response.send_message(
                f"❌ An error occurred: {str(e)}",
                ephemeral=True
            )

async def setup(bot):
    """Add the cog to the bot."""
    # Registra i menu contestuali nel bot
    bot.tree.add_command(send_coupon_context)
    bot.tree.add_command(send_coupon_message_context)
    # Aggiunge il cog
    await bot.add_cog(CouponCog(bot))