# cogs/utilities.py

import discord
import re
import asyncio
import aiohttp
import io
from discord.ext import commands
from discord import app_commands
from typing import Optional, Union, List
from datetime import datetime
import time

class UtilitiesCog(commands.Cog):
    """
    Cog containing utility commands.
    Provides general-purpose commands like whois, avatar, etc.
    """
    
    def __init__(self, bot):
        """Initialize the UtilitiesCog."""
        self.bot = bot
    
    @commands.command(name="whois")
    async def whois_command(self, ctx, *, member: Optional[Union[discord.Member, int]] = None):
        """
        Display information about a user.
        
        Args:
            member: The member to display info for, or their ID. Defaults to the command user.
        """
        # Handle the case where an ID is provided
        if isinstance(member, int):
            try:
                member = await self.bot.fetch_user(member)
                # Try to get as guild member for additional info
                member = ctx.guild.get_member(member.id) or member
            except discord.NotFound:
                await ctx.send("User not found.")
                return
        
        # Default to the command author
        if member is None:
            member = ctx.author
        
        # Check if user has activity in this channel
        last_message = None
        async for message in ctx.channel.history(limit=100):
            if message.author.id == member.id:
                last_message = message
                break
        
        # Format last seen message
        if last_message:
            last_seen_timestamp = int(last_message.created_at.timestamp())
            last_seen_message = (
                f"<a:aemoji_187:1347536765203906642>[<t:{last_seen_timestamp}:R>]({last_message.jump_url})\n"
            )
            
            last_message_info = (
                f"Last message sent in {last_message.channel.mention} at <t:{last_seen_timestamp}:F>:\n"
                f"```{last_message.content[:1000]}```"
            ) if last_message.content else "No text content in last message."
        else:
            last_seen_message = "No recent activity."
            last_message_info = "No recent activity found."
        
        # Get key permissions if the user is a member
        key_permissions = []
        if isinstance(member, discord.Member):
            permissions = member.guild_permissions
            if permissions.administrator:
                key_permissions.append("Administrator")
            if permissions.ban_members:
                key_permissions.append("Ban Members")
            if permissions.kick_members:
                key_permissions.append("Kick Members")
            if permissions.manage_channels:
                key_permissions.append("Manage Channels")
            if permissions.manage_guild:
                key_permissions.append("Manage Guild")
            if permissions.manage_messages:
                key_permissions.append("Manage Messages")
            if permissions.manage_roles:
                key_permissions.append("Manage Roles")
            if permissions.mention_everyone:
                key_permissions.append("Mention Everyone")
        
        # Create the embed
        embed = discord.Embed(
            title=f"Whois {member}",
            color=self.bot.config.get("server.color_theme")
        )
        embed.description = f"**Here is {member.mention}'s Mod view.**\n\n"
        
        # Add general information
        embed.add_field(
            name="__General Information__\n\n",
            value=(
                f"<a:aemoji_187:1347536765203906642>**Nickname:** `{member.nick or 'None'}`\n"
                f"<a:aemoji_187:1347536765203906642>**Mention:** {member.mention}\n"
                f"<a:aemoji_187:1347536765203906642>**Username:** `{member.name}`\n"
                f"<a:aemoji_187:1347536765203906642>**User ID:** `{member.id}`"
            ),
            inline=False
        )
        
        # Add account creation info
        embed.add_field(
            name="__Account Creation Information__",
            value=f"<a:aemoji_187:1347536765203906642>**Date:** <t:{int(member.created_at.timestamp())}:F>",
            inline=False
        )
        
        # Add guild join info if available
        if isinstance(member, discord.Member):
            embed.add_field(
                name="__Guild Join Information__",
                value=f"<a:aemoji_187:1347536765203906642>**Date:** <t:{int(member.joined_at.timestamp())}:F>",
                inline=False
            )
            
            # Add roles
            roles = [role.mention for role in reversed(member.roles) if role.name != '@everyone']
            formatted_roles = []
            for i in range(0, len(roles), 2):
                pair = ' | '.join(roles[i:i+2])
                formatted_roles.append(pair)
            
            roles_display = '\n<a:aemoji_187:1347536765203906642>'.join(formatted_roles)
            embed.add_field(
                name="__Guild Roles__",
                value=f"<a:aemoji_187:1347536765203906642> {roles_display or 'None'}",
                inline=False
            )
        
        # Add last seen field
        embed.add_field(
            name="__Last Seen__",
            value=last_seen_message,
            inline=False
        )
        
        # Set thumbnail to user avatar
        embed.set_thumbnail(url=member.display_avatar.url)
        
        # Try to add banner if available
        try:
            user = await self.bot.fetch_user(member.id)
            if user.banner:
                embed.set_image(url=user.banner.url)
        except:
            pass
        
        # Set footer
        current_time = datetime.now().strftime("%I:%M %p")
        footer_text = f"Requested by {ctx.author.name}  |  Today at {current_time}"
        embed.set_footer(text=footer_text, icon_url=ctx.author.display_avatar.url)
        
        # Create a view with a button to show permissions
        view = discord.ui.View()
        
        if key_permissions:
            permissions_button = discord.ui.Button(
                label="View Permissions",
                emoji="<:emoji_299:1348037476882579517>",
                style=discord.ButtonStyle.success
            )
            
            async def show_permissions(interaction: discord.Interaction):
                if interaction.user != ctx.author:
                    await interaction.response.send_message("You didn't run this command!", ephemeral=True)
                    return
                
                perms_embed = discord.Embed(
                    title="Permissions View",
                    color=discord.Color.dark_grey()
                )
                perms_embed.add_field(
                    name=f"{member.name}'s Key Permissions",
                    value="```\n" + "\n".join(f"- {perm}" for perm in key_permissions) + "\n```",
                    inline=False
                )
                perms_embed.set_footer(
                    text=f"Requested by {ctx.author}",
                    icon_url=ctx.author.display_avatar.url
                )
                
                await interaction.response.send_message(embed=perms_embed, ephemeral=True)
            
            permissions_button.callback = show_permissions
            view.add_item(permissions_button)
        
        # Send the embed
        await ctx.send(embed=embed, view=view)
    
    @app_commands.command(name="whois", description="Display information about a user")
    @app_commands.describe(user="The user to get information about")
    async def whois_slash(self, interaction: discord.Interaction, user: Optional[discord.User] = None):
        """Slash command version of whois."""
        # Set up a context-like object for reusing the command logic
        ctx = await self.bot.get_context(interaction)
        ctx.author = interaction.user
        
        # Use the member if available (for more information)
        if user and interaction.guild:
            member = interaction.guild.get_member(user.id) or user
        else:
            member = user or interaction.user
        
        # Defer the response as this might take a moment
        await interaction.response.defer()
        
        # Call the existing command implementation
        await self.whois_command(ctx, member=member)
    
    @commands.command(name="steal")
    @commands.has_permissions(manage_emojis=True)
    async def steal_emoji(self, ctx, *emojis: str):
        """
        Add custom emojis to the server from other servers.
        
        Args:
            emojis: One or more custom emoji mentions to add
        """
        # Check if the bot has the necessary permissions
        if not ctx.guild.me.guild_permissions.manage_emojis:
            embed = discord.Embed(
                description="### ❌ Missing Permissions\n"
                            "> I do not have the `Manage Emojis` permission.\n"
                            "-# Please check my permissions and ensure I have `Manage Emojis`.",
                color=discord.Color.red()
            )
            await ctx.send(embed=embed)
            return
        
        # Initial status message
        if len(emojis) > 1:
            status_embed = discord.Embed(
                description=f"### ℹ️ Processing Emojis\n"
                            f"> Adding {len(emojis)} emojis with a 30-second delay between each to avoid rate limits.\n"
                            f"-# This will take approximately {len(emojis) * 30} seconds to complete.",
                color=discord.Color.blue()
            )
            await ctx.send(embed=status_embed)
        
        async with aiohttp.ClientSession() as session:
            for i, emoji in enumerate(emojis):
                try:
                    # Check if the emoji is a custom emoji
                    if not emoji.startswith("<") or not emoji.endswith(">"):
                        embed = discord.Embed(
                            description=f"### ❌ Invalid Emoji\n"
                                        f"> `{emoji}` is not a custom emoji.\n"
                                        "-# Only custom emojis can be added to the server.",
                            color=discord.Color.orange()
                        )
                        await ctx.send(embed=embed)
                        continue
                    
                    # Extract emoji information
                    is_animated = emoji.startswith("<a:")
                    emoji_name = emoji.split(":")[1]
                    emoji_id = emoji.split(":")[-1][:-1]  # Remove the trailing ">"
                    emoji_extension = "gif" if is_animated else "png"
                    emoji_url = f"https://cdn.discordapp.com/emojis/{emoji_id}.{emoji_extension}"
                    
                    # Fetch the emoji image
                    async with session.get(emoji_url) as resp:
                        if resp.status != 200:
                            embed = discord.Embed(
                                description=f"### ❌ Failed to Fetch Emoji\n"
                                            f"> Could not fetch the image for `{emoji_name}`.\n"
                                            f"-# HTTP Status: `{resp.status}`",
                                color=discord.Color.red()
                            )
                            await ctx.send(embed=embed)
                            continue
                        
                        emoji_image = await resp.read()
                    
                    # Create the emoji in the server
                    created_emoji = await ctx.guild.create_custom_emoji(
                        name=emoji_name,
                        image=emoji_image
                    )
                    
                    embed = discord.Embed(
                        description=f"### ✅ Emoji Added\n"
                                    f"> Successfully added `{emoji_name}` to the server!\n"
                                    f"-# Preview: {created_emoji}",
                        color=discord.Color.green()
                    )
                    embed.set_thumbnail(url=created_emoji.url)
                    await ctx.send(embed=embed)
                    
                    # Add a delay between emoji additions to avoid rate limiting
                    if i < len(emojis) - 1:
                        delay_embed = discord.Embed(
                            description=f"### ⏱️ Rate Limit Protection\n"
                                        f"> Waiting 30 seconds before adding the next emoji...\n"
                                        f"-# {i+1}/{len(emojis)} emojis processed",
                            color=discord.Color.blue()
                        )
                        await ctx.send(embed=delay_embed)
                        await asyncio.sleep(30)
                    
                except discord.Forbidden:
                    embed = discord.Embed(
                        description="### ❌ Permission Denied\n"
                                    "> I do not have permission to add emojis in this server.\n"
                                    "-# Please check my permissions and try again.",
                        color=discord.Color.red()
                    )
                    await ctx.send(embed=embed)
                    break
                except discord.HTTPException as e:
                    embed = discord.Embed(
                        description=f"### ❌ Error\n"
                                    f"> Failed to add `{emoji_name}` to the server.\n"
                                    f"-# Error: `{str(e)}`",
                        color=discord.Color.red()
                    )
                    await ctx.send(embed=embed)
                except Exception as e:
                    embed = discord.Embed(
                        description=f"### ❌ Unexpected Error\n"
                                    f"> An unexpected error occurred while adding `{emoji_name}`.\n"
                                    f"-# Error: `{str(e)}`",
                        color=discord.Color.red()
                    )
                    await ctx.send(embed=embed)
    
    @app_commands.command(name="steal_emoji", description="Add custom emojis to the server from other servers")
    @app_commands.describe(emoji="The emoji to add to the server")
    @app_commands.default_permissions(manage_emojis=True)
    async def steal_emoji_slash(self, interaction: discord.Interaction, emoji: str):
        """Slash command version of steal emoji."""
        # Set up a context-like object for reusing the command logic
        ctx = await self.bot.get_context(interaction)
        ctx.author = interaction.user
        
        # Defer the response as this might take a moment
        await interaction.response.defer()
        
        # Call the existing command implementation
        await self.steal_emoji(ctx, emoji)
    
    @commands.command(name="ping")
    async def ping(self, ctx):
        """Check the bot's latency."""
        start_time = time.time()
        message = await ctx.send("Pinging...")
        end_time = time.time()
        
        api_latency = round(self.bot.latency * 1000)
        message_latency = round((end_time - start_time) * 1000)
        
        embed = discord.Embed(
            title="🏓 Pong!",
            color=self.bot.config.get("server.color_theme")
        )
        
        embed.add_field(name="API Latency", value=f"{api_latency}ms", inline=True)
        embed.add_field(name="Message Latency", value=f"{message_latency}ms", inline=True)
        
        await message.edit(content=None, embed=embed)
    
    @app_commands.command(name="ping", description="Check the bot's latency")
    async def ping_slash(self, interaction: discord.Interaction):
        """Slash command version of ping."""
        start_time = time.time()
        await interaction.response.defer()
        end_time = time.time()
        
        api_latency = round(self.bot.latency * 1000)
        message_latency = round((end_time - start_time) * 1000)
        
        embed = discord.Embed(
            title="🏓 Pong!",
            color=self.bot.config.get("server.color_theme")
        )
        
        embed.add_field(name="API Latency", value=f"{api_latency}ms", inline=True)
        embed.add_field(name="Message Latency", value=f"{message_latency}ms", inline=True)
        
        await interaction.followup.send(embed=embed)
    
    @commands.command(name="info")
    async def info_command(self, ctx):
        """Display information about the bot."""
        embed = discord.Embed(
            title=f"{self.bot.user.name} Info",
            description="Discord bot for ReelsBuilder community management",
            color=self.bot.config.get("server.color_theme")
        )
        
        # General bot info
        embed.add_field(
            name="Bot",
            value=f"**ID:** {self.bot.user.id}\n**Created:** <t:{int(self.bot.user.created_at.timestamp())}:R>",
            inline=True
        )
        
        # Stats
        guild_count = len(self.bot.guilds)
        user_count = sum(guild.member_count for guild in self.bot.guilds)
        
        embed.add_field(
            name="Stats",
            value=f"**Guilds:** {guild_count}\n**Users:** {user_count}",
            inline=True
        )
        
        # Commands
        command_count = len(self.bot.commands)
        slash_command_count = len(self.bot.tree.get_commands())
        
        embed.add_field(
            name="Commands",
            value=f"**Prefix:** {self.bot.command_prefix}\n**Commands:** {command_count}\n**Slash Commands:** {slash_command_count}",
            inline=True
        )
        
        # Add system info
        import platform
        import psutil
        
        process = psutil.Process()
        memory_usage = process.memory_info().rss / 1024 / 1024  # In MB
        
        embed.add_field(
            name="System",
            value=f"**Python:** {platform.python_version()}\n**Discord.py:** {discord.__version__}\n**Memory:** {memory_usage:.2f} MB",
            inline=True
        )
        
        # Uptime
        bot_uptime = datetime.utcnow() - self.bot.start_time if hasattr(self.bot, "start_time") else None
        if bot_uptime:
            days, remainder = divmod(int(bot_uptime.total_seconds()), 86400)
            hours, remainder = divmod(remainder, 3600)
            minutes, seconds = divmod(remainder, 60)
            
            uptime_str = f"{days}d {hours}h {minutes}m {seconds}s"
            embed.add_field(name="Uptime", value=uptime_str, inline=True)
        
        # Set thumbnail to bot avatar
        embed.set_thumbnail(url=self.bot.user.display_avatar.url)
        
        # Add owner info if available
        try:
            app_info = await self.bot.application_info()
            if app_info.team:
                owners = ", ".join(member.name for member in app_info.team.members)
                embed.add_field(name="Team", value=owners, inline=True)
            else:
                embed.add_field(name="Owner", value=app_info.owner.name, inline=True)
        except:
            pass
        
        await ctx.send(embed=embed)
    
    @app_commands.command(name="info", description="Display information about the bot")
    async def info_slash(self, interaction: discord.Interaction):
       """Slash command version of bot info."""
       # Set up a context-like object for reusing the command logic
       ctx = await self.bot.get_context(interaction)
       ctx.author = interaction.user
       
       # Defer the response
       await interaction.response.defer()
       
       # Call the existing command implementation
       await self.info_command(ctx)

async def setup(bot):
    """Add the cog to the bot."""
    await bot.add_cog(UtilitiesCog(bot))