
# cogs/onboarding.py

import discord
import re
import asyncio
from discord.ext import commands
import datetime
import os

class OnboardingCog(commands.Cog):
    def __init__(self, bot):
        self.bot = bot
        self._load_views()
        self.onboarding_check_task = self.bot.loop.create_task(self.check_inactive_onboarding())
        self.check_left_members_task = self.bot.loop.create_task(self.check_left_members())

    def cog_unload(self):
        if self.onboarding_check_task:
            self.onboarding_check_task.cancel()
        if self.check_left_members_task:
            self.check_left_members_task.cancel()

    def _load_views(self):
        from views.onboarding_views import VerifyMeButton, CTAPanelView
        self.bot.add_view(VerifyMeButton(self.bot))
        self.bot.add_view(CTAPanelView())

    @commands.Cog.listener()
    async def on_member_join(self, member):
        if member.bot:
            return

        guild = member.guild
        staff_role = guild.get_role(self.bot.config.get("server.staff_role_id"))
        if not staff_role:
            self.bot.logger.warning("Staff role not found; skipping onboarding creation.")
            return

        for channel in guild.text_channels:
            if channel.topic and member.mention in channel.topic and "onboard" in channel.topic.lower():
                return  # Already has onboarding

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            member: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True),
            staff_role: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True),
        }

        channel = await guild.create_text_channel(
            name=f"🚀start-{member.name}🤑",
            topic=f"onboard-{member.mention}",
            overwrites=overwrites
        )

        from views.onboarding_views import VerifyMeButton
        embed = discord.Embed(
            description="**💼 Network, Connect, & Earn**\n"
        "Invest, earn, network, and get professional services.\n\n"
        "**🧠 All-in-One Hub**\n"
        "30+ AI utility bots, VIP marketplace, events, and expert support.\n\n"
        "**🎁 Premium Access**\n"
        "$20M+ in giveaways, exclusive resources, and job opportunities.\n\n",
            color=self.bot.config.get("server.color_theme")
        )
        embed.set_footer(text="Step 1: Verification")
        embed.set_image(url="https://cdn.discordapp.com/attachments/1224032780438999140/1348763494958366861/image.png?ex=67f243a4&is=67f0f224&hm=2ab1a3d478bd0aff8079ee33d690d6f312e6e9ce1f322eb926ca835417664c00&")
        await channel.send(content =  f"👋 {member.mention} Welcome to Business Network", embed=embed, view=VerifyMeButton(self.bot))

        self.bot.logger.info(f"Created onboarding channel for {member.name} on join.")

    @commands.command(name="create_onboarding")
    @commands.has_permissions(administrator=True)
    async def create_onboarding(self, ctx, user: discord.Member):
        guild = ctx.guild

        for channel in guild.text_channels:
            if channel.topic and "onboard" in channel.topic.lower() and user.mention in channel.topic:
                await ctx.send(f"{user.mention} already has an onboarding channel: {channel.mention}")
                return

        staff_role = guild.get_role(self.bot.config.get("server.staff_role_id"))
        if not staff_role:
            await ctx.send("Staff role not found!")
            return

        overwrites = {
            guild.default_role: discord.PermissionOverwrite(view_channel=False),
            user: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True),
            staff_role: discord.PermissionOverwrite(view_channel=True, send_messages=True, read_message_history=True),
        }

        channel = await guild.create_text_channel(
            name=f"👋welcome-{user.name}🤑",
            topic=f"onboard-{user.mention}",
            overwrites=overwrites
        )

        embed = discord.Embed(
            title="👋 Welcome to Business Network",
            description="To access your free resources and get started, please verify yourself below.",
            color=self.bot.config.get("server.color_theme")
        )
        embed.set_footer(text="Step 1: Verification")

        from views.onboarding_views import VerifyMeButton
        await channel.send(embed=embed, view=VerifyMeButton(self.bot))
        await ctx.send(f"Created onboarding channel for {user.mention}: {channel.mention}")

    async def check_inactive_onboarding(self):
        await self.bot.wait_until_ready()
        while not self.bot.is_closed():
            try:
                now = datetime.datetime.now(datetime.timezone.utc)
                for guild in self.bot.guilds:
                    for channel in guild.text_channels:
                        if not channel.topic or "onboard" not in channel.topic.lower():
                            continue
                        last_message = None
                        async for message in channel.history(limit=1):
                            last_message = message
                        if not last_message:
                            await channel.delete(reason="Empty onboarding channel")
                            continue
                        timeout = datetime.timedelta(minutes=self.bot.config.get("onboarding.timeout_minutes", 30))
                        if (now - last_message.created_at.replace(tzinfo=datetime.timezone.utc)) > timeout:
                            await channel.delete(reason="Onboarding timeout")
            except Exception as e:
                self.bot.logger.error(f"[Onboarding] Error in inactivity check: {e}")
            await asyncio.sleep(300)

    async def check_left_members(self):
        await self.bot.wait_until_ready()
        while not self.bot.is_closed():
            try:
                for guild in self.bot.guilds:
                    for channel in guild.text_channels:
                        if not channel.topic or "onboard" not in channel.topic.lower():
                            continue
                        member_id = self._extract_member_id(channel.topic)
                        if member_id and not guild.get_member(member_id):
                            await channel.delete(reason="Member left server")
            except Exception as e:
                self.bot.logger.error(f"[Onboarding] Error checking left members: {e}")
            await asyncio.sleep(600)

    def _extract_member_id(self, topic: str):
        if not topic:
            return None
        match = re.search(r"<@!?(\d+)>", topic)
        if match:
            try:
                return int(match.group(1))
            except ValueError:
                return None
        return None

async def setup(bot):
    await bot.add_cog(OnboardingCog(bot))
