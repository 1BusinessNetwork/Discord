# cogs/verification.py

import discord
import asyncio
import datetime
from discord.ext import commands
from typing import Optional, Dict, Any
from views.verification_views import VerificationButton

class VerificationCog(commands.Cog):
    """
    Cog for handling user verification.
    Provides captcha verification for new users.
    """
    
    def __init__(self, bot):
        """Initialize the VerificationCog."""
        self.bot = bot
        self._load_views()
    
    def _load_views(self):
        """Load and register persistent UI views for verification."""
        self.bot.add_view(VerificationButton())
    
    @commands.command(name="verification_panel", aliases=["rverification_panel"])
    @commands.has_permissions(administrator=True)
    async def verification_panel(self, ctx):
        """Create a verification panel for users to verify with captcha."""
        # Create the embed
        embed = discord.Embed(
            title="Access the server!",
            description=(
                "*To begin your journey with us, simply* **click the button below** to __access__ "
                "our onboarding channel and get started! <:BusinessNetworkLogoGreen:1117439122164961411> "
            ),
            color=self.bot.config.get("server.color_theme")
        )
        
        # Add thumbnail (logo)
        embed.set_thumbnail(
            url="https://images-ext-1.discordapp.net/external/Ox2CQq1O9IRBk39D-9wvO-gx2dy7fw5uf8_NsOTwkWY/https/cdn-longterm.mee6.xyz/plugins/embeds/images/800484865774190662/c2b8b7315c69c0093a97cc04517bff693bef3af6756354bf48f31d6367fc1c03.png?format=webp&quality=lossless&width=768&height=768"
        )
        
        # Add main image
        embed.set_image(
            url="https://media.discordapp.net/attachments/1224032780438999140/1348763494958366861/image.png?ex=67f39524&is=67f243a4&hm=62124a63a394a008c227835fd335622bff2340073ed28a77b6a0bbf8563196c4&=&format=webp&quality=lossless&width=409&height=95"
        )
        
        # Add footer
        embed.set_footer(
            text="Business Network | Access",
            icon_url="https://images-ext-1.discordapp.net/external/Ox2CQq1O9IRBk39D-9wvO-gx2dy7fw5uf8_NsOTwkWY/https/cdn-longterm.mee6.xyz/plugins/embeds/images/800484865774190662/c2b8b7315c69c0093a97cc04517bff693bef3af6756354bf48f31d6367fc1c03.png?format=webp&quality=lossless&width=768&height=768"
        )
        
        # Create view
        view = VerificationButton()
        
        # Send the embed
        await ctx.send(embed=embed, view=view)
        
        # Delete the command message
        try:
            await ctx.message.delete()
        except discord.HTTPException:
            pass
    
    @commands.Cog.listener()
    async def on_verification_success(self, member: discord.Member, role_id: int):
        """Event triggered when a user successfully verifies."""
        # This is a custom event that would need to be triggered from the verification view
        
        # Log the verification
        self.bot.logger.info(f"User {member} ({member.id}) successfully verified")
        
        # You could add additional actions here, like:
        # - Sending a welcome message
        # - Adding the user to a database
        # - Creating an onboarding channel

    @commands.Cog.listener()
    async def on_member_join(self, member):
        """Handle new members joining the server."""
        # Skip bots
        if member.bot:
            return
        
        # Skip if verification is not required
        if not self.bot.config.get("verification.enabled", True):
            return
        
        # Check if there's a verification channel configured
        verification_channel_id = self.bot.config.get("verification.channel_id")
        if not verification_channel_id:
            return
        
        verification_channel = member.guild.get_channel(verification_channel_id)
        if not verification_channel:
            return
        
        # DM the user with instructions
        try:
            embed = discord.Embed(
                title="Welcome to the server!",
                description=(
                    f"Welcome to **{member.guild.name}**!\n\n"
                    f"To access the server, please verify yourself in {verification_channel.mention}.\n"
                    f"This helps us protect the server from bots and spam accounts."
                ),
                color=self.bot.config.get("server.color_theme")
            )
            
            embed.set_thumbnail(url=member.guild.icon.url if member.guild.icon else None)
            
            await member.send(embed=embed)
        except discord.Forbidden:
            # Can't DM the user
            pass

async def setup(bot):
    """Add the cog to the bot."""
    await bot.add_cog(VerificationCog(bot))
