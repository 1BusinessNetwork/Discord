# cogs/admin.py

import discord
import os
from discord.ext import commands
from typing import Optional
from utils.permissions import PermissionChecker

class AdminCog(commands.Cog):
    """
    Cog for administrative commands.
    Provides functionality for server management.
    """
    
    def __init__(self, bot):
        """Initialize the AdminCog."""
        self.bot = bot
    
    @commands.command(name="sync")
    @commands.is_owner()
    async def sync_commands(self, ctx, guild_id: Optional[int] = None):
        """
        Sync application commands.
        
        Args:
            guild_id: Optional guild ID to sync commands to a specific server
        """
        if guild_id:
            guild = discord.Object(id=guild_id)
            self.bot.tree.copy_global_to(guild=guild)
            await self.bot.tree.sync(guild=guild)
            await ctx.send(f"Commands synced to guild {guild_id}")
        else:
            await self.bot.tree.sync()
            await ctx.send("Global commands synced")

async def setup(bot):
    """Add the cog to the bot."""
    await bot.add_cog(AdminCog(bot))
