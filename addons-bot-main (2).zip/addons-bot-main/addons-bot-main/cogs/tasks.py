# cogs/tasks.py

import discord
import asyncio
import datetime
import json
import os
import re
from discord.ext import commands, tasks
from typing import Optional, Dict, List, Any, Tuple

class TasksCog(commands.Cog):
    """
    Cog for scheduling and running background tasks.
    Handles tasks like checking inactive tickets, temporary role removal, etc.
    """
    
    def __init__(self, bot):
        """Initialize the TasksCog."""
        self.bot = bot
        
        # Start background tasks
        self.check_inactive_tickets.start()
        self.check_role_removals.start()
    
    def cog_unload(self):
        """Clean up when the cog is unloaded."""
        self.check_inactive_tickets.cancel()
        self.check_role_removals.cancel()
    
    @tasks.loop(minutes=10)
    async def check_inactive_tickets(self):
        """Check for inactive ticket channels and close/delete them if needed."""
        # Wait until the bot is ready
        if not self.bot.is_ready():
            return
        
        self.bot.logger.info("Running task: check_inactive_tickets")
        now = datetime.datetime.now(datetime.timezone.utc)
        
        for guild in self.bot.guilds:
            for channel in guild.text_channels:
                # Skip if not a ticket channel
                if not channel.topic or "ticket" not in channel.topic.lower():
                    continue
                
                # Check if it's an onboarding ticket
                is_onboarding = "onboard" in channel.topic.lower()
                
                # Skip regular tickets (only auto-close onboarding tickets)
                if not is_onboarding:
                    continue
                
                # Get the last message
                last_message = None
                async for message in channel.history(limit=1):
                    last_message = message
                
                if not last_message:
                    # No messages found, delete the channel
                    try:
                        self.bot.logger.info(f"Deleting empty ticket channel: {channel.name} ({channel.id})")
                        await self._cleanup_verification_role(channel)
                        await channel.delete(reason="Ticket has no messages")
                    except discord.HTTPException as e:
                        self.bot.logger.error(f"Failed to delete channel {channel.name}: {e}")
                    continue
                
                # Determine timeout based on ticket type
                if "onboard-ticket-" in channel.topic.lower():
                    # Post-form ticket has 24h timeout
                    timeout = datetime.timedelta(hours=24)
                else:
                    # Regular onboarding ticket has configurable timeout (default 30m)
                    timeout_minutes = self.bot.config.get("onboarding.timeout_minutes", 30)
                    timeout = datetime.timedelta(minutes=timeout_minutes)
                
                # Calculate time difference
                time_difference = now - last_message.created_at.replace(tzinfo=datetime.timezone.utc)
                
                if time_difference > timeout:
                    self.bot.logger.info(f"Closing inactive ticket: {channel.name} ({channel.id})")
                    
                    # Create transcript
                    try:
                        await self.bot.transcript_manager.log_transcript(channel)
                    except Exception as e:
                        self.bot.logger.error(f"Failed to create transcript for {channel.name}: {e}")
                    
                    # Remove verification role if it's an onboarding ticket
                    await self._cleanup_verification_role(channel)
                    
                    # Delete the channel
                    try:
                        await channel.delete(reason="Ticket timed out due to inactivity")
                    except discord.HTTPException as e:
                        self.bot.logger.error(f"Failed to delete inactive ticket {channel.name}: {e}")
                
                # Add a small delay to prevent rate limits
                await asyncio.sleep(2)
    
    async def _cleanup_verification_role(self, channel):
        """Remove verification role from user if ticket is an onboarding ticket."""
        # Skip if not an onboarding ticket
        if not channel.topic or "onboard" not in channel.topic.lower():
            return
        
        # Extract the ticket owner
        ticket_owner = await self._get_ticket_owner(channel)
        if not ticket_owner:
            return
        
        # Remove verification role if configured
        verification_role_id = self.bot.config.get("server.verification_role_id")
        if verification_role_id:
            role = channel.guild.get_role(verification_role_id)
            if role and role in ticket_owner.roles:
                try:
                    await ticket_owner.remove_roles(
                        role,
                        reason="Onboarding ticket closed due to inactivity"
                    )
                    self.bot.logger.info(f"Removed verification role from {ticket_owner} due to inactive onboarding")
                except discord.HTTPException as e:
                    self.bot.logger.error(f"Failed to remove verification role: {e}")
    
    async def _get_ticket_owner(self, channel):
        """Extract ticket owner from channel topic."""
        if not channel.topic:
            return None
        
        matches = re.findall(r"<@!?(\d+)>", channel.topic)
        if not matches:
            return None
        
        try:
            user_id = int(matches[0])
            return channel.guild.get_member(user_id)
        except (ValueError, IndexError):
            return None
    
    @check_inactive_tickets.before_loop
    async def before_check_inactive_tickets(self):
        """Wait until the bot is ready before starting the task."""
        await self.bot.wait_until_ready()
    
    @tasks.loop(minutes=5)
    async def check_role_removals(self):
        """Check for temporary roles that need to be removed."""
        # Wait until the bot is ready
        if not self.bot.is_ready():
            return
        
        self.bot.logger.info("Running task: check_role_removals")
        now = datetime.datetime.utcnow()
        
        # Load pending role removals
        pending_removals = {}
        try:
            pending_removals_file = "data/storage/pending_roles.json"
            if os.path.exists(pending_removals_file):
                with open(pending_removals_file, "r") as f:
                    pending_removals = json.load(f)
        except Exception as e:
            self.bot.logger.error(f"Error loading pending role removals: {e}")
            return
        
        modified = False
        to_remove = []
        
        for member_id, roles in pending_removals.items():
            updated_roles = []
            
            for role_data in roles:
                removal_time = datetime.datetime.fromisoformat(role_data["removal_time"])
                role_id = role_data["role_id"]
                
                # Find the guild and role
                role = None
                guild = None
                member = None
                
                for g in self.bot.guilds:
                    r = g.get_role(role_id)
                    if r:
                        role = r
                        guild = g
                        member = guild.get_member(int(member_id))
                        break
                
                if not guild or not role or not member:
                    continue
                
                if now >= removal_time:
                    if role in member.roles:
                        try:
                            await member.remove_roles(
                                role,
                                reason="Temporary role duration expired"
                            )
                            self.bot.logger.info(f"Removed temporary role {role.name} from {member}")
                            modified = True
                        except discord.HTTPException as e:
                            self.bot.logger.error(f"Failed to remove role {role.name} from {member}: {e}")
                            updated_roles.append(role_data)  # Keep in list to try again later
                else:
                    updated_roles.append(role_data)
            
            if updated_roles:
                pending_removals[member_id] = updated_roles
            else:
                to_remove.append(member_id)
        
        # Remove completed entries
        for member_id in to_remove:
            pending_removals.pop(member_id)
            modified = True
        
        # Save updated removals if modified
        if modified:
            try:
                os.makedirs("data/storage", exist_ok=True)
                with open(pending_removals_file, "w") as f:
                    json.dump(pending_removals, f, indent=4)
            except Exception as e:
                self.bot.logger.error(f"Error saving pending role removals: {e}")
    
    @check_role_removals.before_loop
    async def before_check_role_removals(self):
        """Wait until the bot is ready before starting the task."""
        await self.bot.wait_until_ready()

async def setup(bot):
    """Add the cog to the bot."""
    await bot.add_cog(TasksCog(bot))