# cogs/roles.py

import discord
import json
import os
import datetime
from discord.ext import commands
from discord import app_commands
from typing import Optional, Dict, List, Any, Union

class RolesCog(commands.Cog):
    """
    Cog for managing roles.
    Provides functionality for assigning temporary roles and other role-related features.
    """
    
    def __init__(self, bot):
        """Initialize the RolesCog."""
        self.bot = bot
        self.pending_removals_file = "data/storage/pending_roles.json"
        self.pending_removals = self._load_pending_removals()
    
    def _load_pending_removals(self) -> Dict[str, List[Dict[str, Any]]]:
        """Load pending role removals from file."""
        try:
            if os.path.exists(self.pending_removals_file):
                with open(self.pending_removals_file, "r") as f:
                    return json.load(f)
            else:
                return {}
        except Exception as e:
            self.bot.logger.error(f"Error loading pending role removals: {e}")
            return {}
    
    def _save_pending_removals(self) -> bool:
        """Save pending role removals to file."""
        try:
            # Ensure directory exists
            os.makedirs(os.path.dirname(self.pending_removals_file), exist_ok=True)
            
            with open(self.pending_removals_file, "w") as f:
                json.dump(self.pending_removals, f, indent=4)
            return True
        except Exception as e:
            self.bot.logger.error(f"Error saving pending role removals: {e}")
            return False
    
    @commands.command(name="temprole")
    @commands.has_permissions(manage_roles=True)
    async def temp_role(self, ctx, member: discord.Member, role: discord.Role, duration: str):
        """
        Assign a temporary role to a member.
        
        Args:
            member: The member to assign the role to
            role: The role to assign
            duration: Duration for the role (e.g., 10m, 1h, 1d)
        """
        # Check if bot has permission to manage roles
        if not ctx.guild.me.guild_permissions.manage_roles:
            await ctx.send("I don't have permission to manage roles.")
            return
        
        # Check if the role is higher than the bot's highest role
        if role.position >= ctx.guild.me.top_role.position:
            await ctx.send("I can't assign roles higher than my highest role.")
            return
        
        # Convert duration to seconds
        time_multiplier = {"m": 60, "h": 3600, "d": 86400}
        try:
            time_unit = duration[-1]  # Last character
            time_value = int(duration[:-1])  # Everything except the last character
            
            if time_unit not in time_multiplier:
                await ctx.send("Invalid time unit! Use 'm' for minutes, 'h' for hours, or 'd' for days.")
                return
            
            time_seconds = time_value * time_multiplier[time_unit]
        except ValueError:
            await ctx.send("Invalid duration format! Use a number followed by 'm', 'h', or 'd' (e.g., 10m).")
            return
        
        # Check if user already has the role
        if role in member.roles:
            await ctx.send(f"{member.mention} already has the role {role.name}.")
            return
        
        # Add the role
        try:
            await member.add_roles(role, reason=f"Temporary role for {duration} by {ctx.author}")
            
            # Calculate the removal time
            removal_time = datetime.datetime.utcnow() + datetime.timedelta(seconds=time_seconds)
            
            # Save the role removal task
            member_id = str(member.id)
            if member_id not in self.pending_removals:
                self.pending_removals[member_id] = []
            
            self.pending_removals[member_id].append({
                "role_id": role.id,
                "removal_time": removal_time.isoformat()
            })
            
            # Save to file
            self._save_pending_removals()
            
            # Convert to human-readable format for display
            human_time = ""
            if time_value > 0:
                if time_unit == "m":
                    human_time = f"{time_value} minute{'s' if time_value != 1 else ''}"
                elif time_unit == "h":
                    human_time = f"{time_value} hour{'s' if time_value != 1 else ''}"
                elif time_unit == "d":
                    human_time = f"{time_value} day{'s' if time_value != 1 else ''}"
            
            # Success message
            embed = discord.Embed(
                title="Temporary Role Assigned",
                description=f"Role {role.mention} has been assigned to {member.mention} for {human_time}.",
                color=self.bot.config.get("server.color_theme")
            )
            
            embed.add_field(
                name="Expiration",
                value=f"<t:{int(removal_time.timestamp())}:F> (<t:{int(removal_time.timestamp())}:R>)",
                inline=False
            )
            
            await ctx.send(embed=embed)
            
            # Log the action
            self.bot.logger.info(
                f"Temporary role '{role.name}' assigned to {member} for {duration} by {ctx.author}"
            )
            
        except discord.Forbidden:
            await ctx.send("I don't have permission to assign that role.")
        except discord.HTTPException as e:
            await ctx.send(f"An error occurred: {e}")
    
    @app_commands.command(
        name="temprole",
        description="Assign a temporary role to a member"
    )
    @app_commands.describe(
        member="The member to assign the role to",
        role="The role to assign",
        duration="Duration for the role (e.g., 10m, 1h, 1d)"
    )
    @app_commands.default_permissions(manage_roles=True)
    async def temp_role_slash(
        self,
        interaction: discord.Interaction,
        member: discord.Member,
        role: discord.Role,
        duration: str
    ):
        """Slash command to assign a temporary role to a member."""
        # Check if bot has permission to manage roles
        if not interaction.guild.me.guild_permissions.manage_roles:
            await interaction.response.send_message("I don't have permission to manage roles.", ephemeral=True)
            return
        
        # Check if the role is higher than the bot's highest role
        if role.position >= interaction.guild.me.top_role.position:
            await interaction.response.send_message(
                "I can't assign roles higher than my highest role.",
                ephemeral=True
            )
            return
        
        # Convert duration to seconds
        time_multiplier = {"m": 60, "h": 3600, "d": 86400}
        try:
            time_unit = duration[-1]  # Last character
            time_value = int(duration[:-1])  # Everything except the last character
            
            if time_unit not in time_multiplier:
                await interaction.response.send_message(
                    "Invalid time unit! Use 'm' for minutes, 'h' for hours, or 'd' for days.",
                    ephemeral=True
                )
                return
            
            time_seconds = time_value * time_multiplier[time_unit]
        except ValueError:
            await interaction.response.send_message(
                "Invalid duration format! Use a number followed by 'm', 'h', or 'd' (e.g., 10m).",
                ephemeral=True
            )
            return
        
        # Check if user already has the role
        if role in member.roles:
            await interaction.response.send_message(
                f"{member.mention} already has the role {role.name}.",
                ephemeral=True
            )
            return
        
        # Add the role
        try:
            await member.add_roles(role, reason=f"Temporary role for {duration} by {interaction.user}")
            
            # Calculate the removal time
            removal_time = datetime.datetime.utcnow() + datetime.timedelta(seconds=time_seconds)
            
            # Save the role removal task
            member_id = str(member.id)
            if member_id not in self.pending_removals:
                self.pending_removals[member_id] = []
            
            self.pending_removals[member_id].append({
                "role_id": role.id,
                "removal_time": removal_time.isoformat()
            })
            
            # Save to file
            self._save_pending_removals()
            
            # Convert to human-readable format for display
            human_time = ""
            if time_value > 0:
                if time_unit == "m":
                    human_time = f"{time_value} minute{'s' if time_value != 1 else ''}"
                elif time_unit == "h":
                    human_time = f"{time_value} hour{'s' if time_value != 1 else ''}"
                elif time_unit == "d":
                    human_time = f"{time_value} day{'s' if time_value != 1 else ''}"
            
            # Success message
            embed = discord.Embed(
                title="Temporary Role Assigned",
                description=f"Role {role.mention} has been assigned to {member.mention} for {human_time}.",
                color=self.bot.config.get("server.color_theme")
            )
            
            embed.add_field(
                name="Expiration",
                value=f"<t:{int(removal_time.timestamp())}:F> (<t:{int(removal_time.timestamp())}:R>)",
                inline=False
            )
            
            await interaction.response.send_message(embed=embed)
            
            # Log the action
            self.bot.logger.info(
                f"Temporary role '{role.name}' assigned to {member} for {duration} by {interaction.user}"
            )
            
        except discord.Forbidden:
            await interaction.response.send_message("I don't have permission to assign that role.", ephemeral=True)
        except discord.HTTPException as e:
            await interaction.response.send_message(f"An error occurred: {e}", ephemeral=True)
    
    @commands.command(name="roleinfo")
    async def role_info(self, ctx, *, role: discord.Role):
        """
        Display information about a role.
        
        Args:
            role: The role to display information for
        """
        # Create embed
        embed = discord.Embed(
            title=f"Role Information: {role.name}",
            color=role.color
        )
        
        # Add basic information
        embed.add_field(name="ID", value=role.id, inline=True)
        embed.add_field(name="Color", value=f"#{role.color.value:06x}", inline=True)
        embed.add_field(name="Position", value=role.position, inline=True)
        
        # Add member count
        member_count = len(role.members)
        embed.add_field(name="Members", value=member_count, inline=True)
        
        # Add role properties
        properties = []
        if role.hoist:
            properties.append("Displayed separately")
        if role.mentionable:
            properties.append("Mentionable")
        if role.managed:
            properties.append("Managed by integration")
        
        embed.add_field(
            name="Properties",
            value=", ".join(properties) if properties else "None",
            inline=True
        )
        
        # Add creation date
        created_at = int(role.created_at.timestamp())
        embed.add_field(
            name="Created",
            value=f"<t:{created_at}:F> (<t:{created_at}:R>)",
            inline=True
        )
        
        # Add permissions if they can be calculated
        try:
            permissions = ", ".join(
                perm.replace("_", " ").title() for perm, value in role.permissions if value
            )
            
            if permissions:
                embed.add_field(
                    name="Key Permissions",
                    value=permissions,
                    inline=False
                )
        except:
            pass
        
        await ctx.send(embed=embed)
    
    @app_commands.command(
        name="roleinfo",
        description="Display information about a role"
    )
    @app_commands.describe(role="The role to display information for")
    async def role_info_slash(self, interaction: discord.Interaction, role: discord.Role):
        """Slash command to display information about a role."""
        # Create embed
        embed = discord.Embed(
            title=f"Role Information: {role.name}",
            color=role.color
        )
        
        # Add basic information
        embed.add_field(name="ID", value=role.id, inline=True)
        embed.add_field(name="Color", value=f"#{role.color.value:06x}", inline=True)
        embed.add_field(name="Position", value=role.position, inline=True)
        
        # Add member count
        member_count = len(role.members)
        embed.add_field(name="Members", value=member_count, inline=True)
        
        # Add role properties
        properties = []
        if role.hoist:
            properties.append("Displayed separately")
        if role.mentionable:
            properties.append("Mentionable")
        if role.managed:
            properties.append("Managed by integration")
        
        embed.add_field(
            name="Properties",
            value=", ".join(properties) if properties else "None",
            inline=True
        )
        
        # Add creation date
        created_at = int(role.created_at.timestamp())
        embed.add_field(
            name="Created",
            value=f"<t:{created_at}:F> (<t:{created_at}:R>)",
            inline=True
        )
        
        # Add permissions if they can be calculated
        try:
            permissions = ", ".join(
                perm.replace("_", " ").title() for perm, value in role.permissions if value
            )
            
            if permissions:
                embed.add_field(
                    name="Key Permissions",
                    value=permissions,
                    inline=False
                )
        except:
            pass
        
        await interaction.response.send_message(embed=embed)
    
    @commands.command(name="rolemembers")
    async def role_members(self, ctx, *, role: discord.Role):
        """
        List members who have a specific role.
        
        Args:
            role: The role to list members for
        """
        members = role.members
        
        if not members:
            await ctx.send(f"No members have the {role.mention} role.")
            return
        
        # Create pages of members
        members_per_page = 20
        pages = [members[i:i + members_per_page] for i in range(0, len(members), members_per_page)]
        
        # Create initial embed
        embed = discord.Embed(
            title=f"Members with {role.name} role",
            description=f"Total members: {len(members)}",
            color=role.color
        )
        
        # Add members to the first page
        member_list = "\n".join(f"{i+1}. {member.mention} ({member.name})" for i, member in enumerate(pages[0]))
        embed.add_field(name="Members", value=member_list, inline=False)
        
        # Add page number
        embed.set_footer(text=f"Page 1/{len(pages)}")
        
        # If only one page, just send it
        if len(pages) == 1:
            await ctx.send(embed=embed)
            return
        
        # Create navigation view for multiple pages
        class RoleMembersView(discord.ui.View):
            def __init__(self, pages, role):
                super().__init__(timeout=60)
                self.pages = pages
                self.role = role
                self.current_page = 0
            
            @discord.ui.button(label="Previous", style=discord.ButtonStyle.gray)
            async def previous_button(self, interaction: discord.Interaction, button: discord.ui.Button):
                if interaction.user != ctx.author:
                    await interaction.response.send_message("You can't use this button!", ephemeral=True)
                    return
                
                self.current_page = (self.current_page - 1) % len(self.pages)
                await self.update_page(interaction)
            
            @discord.ui.button(label="Next", style=discord.ButtonStyle.gray)
            async def next_button(self, interaction: discord.Interaction, button: discord.ui.Button):
                if interaction.user != ctx.author:
                    await interaction.response.send_message("You can't use this button!", ephemeral=True)
                    return
                
                self.current_page = (self.current_page + 1) % len(self.pages)
                await self.update_page(interaction)
            
            async def update_page(self, interaction: discord.Interaction):
                embed = discord.Embed(
                    title=f"Members with {self.role.name} role",
                    description=f"Total members: {len(sum(self.pages, []))}",
                    color=self.role.color
                )
                
                # Add members to the page
                start_idx = self.current_page * members_per_page
                member_list = "\n".join(
                    f"{start_idx+i+1}. {member.mention} ({member.name})"
                    for i, member in enumerate(self.pages[self.current_page])
                )
                embed.add_field(name="Members", value=member_list, inline=False)
                
                # Add page number
                embed.set_footer(text=f"Page {self.current_page+1}/{len(self.pages)}")
                
                await interaction.response.edit_message(embed=embed, view=self)
        
        # Send the paginated embed
        view = RoleMembersView(pages, role)
        await ctx.send(embed=embed, view=view)
    
    @app_commands.command(
        name="rolemembers",
        description="List members who have a specific role"
    )
    @app_commands.describe(role="The role to list members for")
    async def role_members_slash(self, interaction: discord.Interaction, role: discord.Role):
        """Slash command to list members who have a specific role."""
        members = role.members
        
        if not members:
            await interaction.response.send_message(f"No members have the {role.mention} role.")
            return
        
        # Create pages of members
        members_per_page = 20
        pages = [members[i:i + members_per_page] for i in range(0, len(members), members_per_page)]
        
        # Create initial embed
        embed = discord.Embed(
            title=f"Members with {role.name} role",
            description=f"Total members: {len(members)}",
            color=role.color
        )
        
        # Add members to the first page
        member_list = "\n".join(f"{i+1}. {member.mention} ({member.name})" for i, member in enumerate(pages[0]))
        embed.add_field(name="Members", value=member_list, inline=False)
        
        # Add page number
        embed.set_footer(text=f"Page 1/{len(pages)}")
        
        # If only one page, just send it
        if len(pages) == 1:
            await interaction.response.send_message(embed=embed)
            return
        
        # Create navigation view for multiple pages
        class RoleMembersView(discord.ui.View):
            def __init__(self, pages, role):
                super().__init__(timeout=60)
                self.pages = pages
                self.role = role
                self.current_page = 0
            
            @discord.ui.button(label="Previous", style=discord.ButtonStyle.gray)
            async def previous_button(self, interaction: discord.Interaction, button: discord.ui.Button):
                self.current_page = (self.current_page - 1) % len(self.pages)
                await self.update_page(interaction)
            
            @discord.ui.button(label="Next", style=discord.ButtonStyle.gray)
            async def next_button(self, interaction: discord.Interaction, button: discord.ui.Button):
                self.current_page = (self.current_page + 1) % len(self.pages)
                await self.update_page(interaction)
            
            async def update_page(self, interaction: discord.Interaction):
                embed = discord.Embed(
                    title=f"Members with {self.role.name} role",
                    description=f"Total members: {len(sum(self.pages, []))}",
                    color=self.role.color
                )
                
                # Add members to the page
                start_idx = self.current_page * members_per_page
                member_list = "\n".join(
                    f"{start_idx+i+1}. {member.mention} ({member.name})"
                    for i, member in enumerate(self.pages[self.current_page])
                )
                embed.add_field(name="Members", value=member_list, inline=False)
                
                # Add page number
                embed.set_footer(text=f"Page {self.current_page+1}/{len(self.pages)}")
                
                await interaction.response.edit_message(embed=embed, view=self)
        
        # Send the paginated embed
        view = RoleMembersView(pages, role)
        await interaction.response.send_message(embed=embed, view=view)

async def setup(bot):
    """Add the cog to the bot."""
    await bot.add_cog(RolesCog(bot))