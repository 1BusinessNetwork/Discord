# utils/captcha.py

import io
import random
import string
from PIL import Image, ImageDraw, ImageFont
from typing import Tuple

class CaptchaGenerator:
    """
    Utility for generating CAPTCHA images with text.
    Used for server verification system.
    """
    
    @staticmethod
    def generate_code(length: int = 3) -> str:
        """
        Generate a random captcha code.
        
        Args:
            length: Length of the captcha code
            
        Returns:
            Random captcha code
        """
        # Use only uppercase letters that are less ambiguous
        characters = string.ascii_uppercase
        # Remove similar looking characters
        for char in 'OI01':
            characters = characters.replace(char, '')
        
        return ''.join(random.choice(characters) for _ in range(length))
    
    @staticmethod
    def generate_image(text: str, width: int = 400, height: int = 200) -> io.BytesIO:
        """
        Generate a captcha image with the given text.
        
        Args:
            text: Text to display in the captcha
            width: Width of the image
            height: Height of the image
            
        Returns:
            BytesIO containing the captcha image in PNG format
        """
        # Create a blank image with white background
        image = Image.new('RGB', (width, height), color='white')
        draw = ImageDraw.Draw(image)
        
        # Try to use a built-in font, or default to a simple font if not available
        try:
            font_size = 90  # Increased font size
            font = ImageFont.truetype("arial.ttf", font_size)
        except IOError:
            font = ImageFont.load_default()
        
        # Calculate text size to center it
        try:
            # Use textbbox instead of deprecated textsize
            left, top, right, bottom = draw.textbbox((0, 0), text, font=font)
            text_width, text_height = right - left, bottom - top
        except AttributeError:
            # Fallback if textbbox is not available
            text_width, text_height = font.getsize(text) if hasattr(font, 'getsize') else (font_size * len(text), font_size)
        
        # Improved horizontal centering with offset
        x = (width - text_width) // 2
        y = (height - text_height) // 2
        
        # Add minimal noise (random dots)
        for _ in range(200):
            x1 = random.randint(0, width)
            y1 = random.randint(0, height)
            draw.point((x1, y1), fill=(random.randint(200, 240), random.randint(200, 240), random.randint(200, 240)))
        
        # Add minimal random lines
        for _ in range(3):
            x1 = random.randint(0, width)
            y1 = random.randint(0, height)
            x2 = random.randint(0, width)
            y2 = random.randint(0, height)
            draw.line((x1, y1, x2, y2), fill=(random.randint(200, 240), random.randint(200, 240), random.randint(200, 240)), width=1)
        
        # Draw text with better spacing between characters
        for i, char in enumerate(text):
            char_x = x + i * (font_size * 1.1)  # Increased spacing
            char_y = y + random.randint(-2, 2)  # Minimal vertical shift
            draw.text((char_x, char_y), char, font=font, fill=(0, 0, 0))
        
        # Convert PIL image to bytes
        byte_array = io.BytesIO()
        image.save(byte_array, format='PNG')
        byte_array.seek(0)
        
        return byte_array