# utils/__init__.py

"""
Utilities package for helper functions and classes.
"""
async def setup(bot):
    pass  # Nessuna azione specifica richiesta per questo pacchetto