# utils/transcript.py

import discord
import os
import io
import re
import chat_exporter
from datetime import datetime
from typing import Optional, Union, Dict, List, Tuple

class TranscriptManager:
    """
    Utility for managing the creation and storage of ticket transcripts.
    """
    
    def __init__(self, bot):
        """
        Initialize the TranscriptManager.
        
        Args:
            bot: The Discord bot instance
        """
        self.bot = bot
        self.base_dir = "/app/transcripts"
        self.assets_dir = "/app/transcripts/assets"
        
        # Ensure directories exist
        os.makedirs(self.base_dir, exist_ok=True)
        os.makedirs(self.assets_dir, exist_ok=True)
    
    async def get_ticket_owner(self, channel: discord.TextChannel) -> Optional[discord.Member]:
        """
        Extract the ticket owner from the channel topic.
        
        Args:
            channel: The ticket channel
            
        Returns:
            The ticket owner or None if not found
        """
        if not channel.topic:
            return None
        
        matches = re.findall(r"<@!?(\d+)>", channel.topic)
        if not matches:
            return None
        
        try:
            user_id = int(matches[0])
            return channel.guild.get_member(user_id)
        except (ValueError, IndexError):
            return None
    
    async def count_messages_per_user(self, channel: discord.TextChannel) -> Dict[discord.User, int]:
        """
        Count messages per user in the channel.
        
        Args:
            channel: The ticket channel
            
        Returns:
            Dict mapping users to their message counts
        """
        user_message_counts = {}
        
        async for message in channel.history(limit=None):
            user_message_counts[message.author] = user_message_counts.get(message.author, 0) + 1
        
        return user_message_counts
    
    async def create_transcript(self, channel: discord.TextChannel) -> Tuple[str, str]:
        """
        Create a transcript of the channel.
        
        Args:
            channel: The ticket channel
            
        Returns:
            Tuple of (transcript filename, local file path)
        """
        # Ensure directories exist
        os.makedirs(self.base_dir, exist_ok=True)
        os.makedirs(self.assets_dir, exist_ok=True)
        
        # Export transcript using chat_exporter
        transcript = await chat_exporter.export(
            channel,
            limit=None,
            military_time=False,
        )
        
        if not transcript:
            raise ValueError("Failed to generate transcript")
        
        # Define output path and filename
        timestamp = datetime.utcnow().strftime("%Y%m%d-%H%M%S")
        filename = f"transcript-{channel.id}.html"
        file_path = os.path.join(self.base_dir, filename)
        
        # Create parent directory if it doesn't exist
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        
        # Save the transcript locally
        try:
            with open(file_path, "w", encoding="utf-8") as f:
                f.write(transcript)
        except OSError as e:
            self.bot.logger.error(f"Error saving transcript to file: {e}")
            raise
        
        return filename, file_path
    
    async def log_transcript(self, channel: discord.TextChannel, deleted_by: Optional[discord.Member] = None) -> bool:
        """
        Create a transcript and log it to the transcript channel.
        
        Args:
            channel: The ticket channel
            deleted_by: Member who deleted the ticket (optional)
            
        Returns:
            True if successful, False otherwise
        """
        try:
            # Get transcript log channel ID from config
            transcript_channel_id = self.bot.config.get("tickets.transcript_channel_id")
            if not transcript_channel_id:
                self.bot.logger.error("No transcript channel ID configured")
                return False
            
            transcript_channel = self.bot.get_channel(transcript_channel_id)
            if not transcript_channel:
                self.bot.logger.error(f"Transcript channel {transcript_channel_id} not found")
                return False
            
            # Get ticket information
            ticket_owner = await self.get_ticket_owner(channel)
            user_message_counts = await self.count_messages_per_user(channel)
            
            # Create transcript
            try:
                filename, file_path = await self.create_transcript(channel)
            except Exception as e:
                self.bot.logger.error(f"Error creating transcript: {e}")
                return False
            
            # Create embed
            embed = discord.Embed(
                title="Transcript Generated!",
                description="The transcript has been saved successfully.",
                color=discord.Color.green(),
                timestamp=datetime.utcnow()
            )
            
            # Add fields with ticket information
            try:
                category_name = channel.category.name if channel.category else "Uncategorized"
            except AttributeError:
                category_name = "Uncategorized"
            
            embed.add_field(name="Category:", value=category_name, inline=False)
            embed.add_field(name="Ticket Name:", value=channel.name, inline=False)
            embed.add_field(name="Opened By:", value=ticket_owner.mention if ticket_owner else 'Unknown', inline=False)
            
            if deleted_by:
                embed.add_field(name="Deleted By:", value=deleted_by.mention, inline=False)
            
            # Format message counts
            if user_message_counts:
                user_message_details = "\n".join(
                    [f"• {user.mention} - {count} Messages" for user, count in user_message_counts.items()]
                )
            else:
                user_message_details = "No messages found"
            
            embed.add_field(name="Users in Ticket:", value=user_message_details, inline=False)
            
            # Create a view with a link button
            base_url = self.bot.config.get("web.base_url", "https://transcripts.reelsbuilder.ai")
            transcript_url = f"{base_url}/transcripts/{filename}"
            
            view = discord.ui.View()
            view.add_item(discord.ui.Button(
                label="View Transcript",
                url=transcript_url,
                style=discord.ButtonStyle.link
            ))
            
            # Send the transcript to the log channel
            try:
                await transcript_channel.send(
                    file=discord.File(file_path, filename=filename),
                    embed=embed,
                    view=view
                )
            except discord.HTTPException as e:
                self.bot.logger.error(f"Error sending transcript to log channel: {e}")
                return False
            
            self.bot.logger.info(f"Transcript for {channel.name} ({channel.id}) saved and logged")
            return True
            
        except Exception as e:
            self.bot.logger.error(f"Error logging transcript: {e}", exc_info=True)
            return False
