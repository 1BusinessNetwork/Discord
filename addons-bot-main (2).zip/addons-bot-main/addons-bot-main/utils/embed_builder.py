# utils/embed_builder.py

import discord
from datetime import datetime
from typing import Optional, List, Union, Dict, Any

class EmbedBuilder:
    """
    Utility class for creating consistent Discord embeds throughout the bot.
    """
    
    def __init__(self, bot):
        """
        Initialize the EmbedBuilder.
        
        Args:
            bot: The Discord bot instance (for accessing config)
        """
        self.bot = bot
        self.config = bot.config
    
    def get_color(self, color_type: str = "default") -> int:
        """
        Get color value based on type.
        
        Args:
            color_type: Type of color to use
            
        Returns:
            Discord color integer
        """
        colors = {
            "default": self.config.get("server.color_theme", 0xEC7110),
            "success": 0x57F287,  # Discord green
            "warning": 0xFEE75C,  # Discord yellow
            "error": 0xED4245,    # Discord red
            "info": 0x5865F2      # Discord blue
        }
        
        return colors.get(color_type, colors["default"])
    
    def build(
        self,
        title: Optional[str] = None,
        description: Optional[str] = None,
        color_type: str = "default",
        timestamp: bool = True,
        author: Optional[Dict[str, str]] = None,
        footer: Optional[Dict[str, str]] = None,
        thumbnail: Optional[str] = None,
        image: Optional[str] = None,
        fields: Optional[List[Dict[str, Any]]] = None,
        url: Optional[str] = None
    ) -> discord.Embed:
        """
        Build a Discord embed with standardized formatting.
        
        Args:
            title: Embed title
            description: Embed description
            color_type: Type of color to use
            timestamp: Whether to include current timestamp
            author: Author information (name, icon_url, url)
            footer: Footer information (text, icon_url)
            thumbnail: URL for thumbnail image
            image: URL for main image
            fields: List of fields (name, value, inline)
            url: URL for the embed title
            
        Returns:
            Formatted Discord embed
        """
        embed = discord.Embed(
            title=title,
            description=description,
            color=self.get_color(color_type),
            url=url
        )
        
        if timestamp:
            embed.timestamp = datetime.utcnow()
        
        if author:
            embed.set_author(
                name=author.get("name", ""),
                icon_url=author.get("icon_url"),
                url=author.get("url")
            )
        
        if footer:
            embed.set_footer(
                text=footer.get("text", ""),
                icon_url=footer.get("icon_url")
            )
        
        if thumbnail:
            embed.set_thumbnail(url=thumbnail)
        
        if image:
            embed.set_image(url=image)
        
        if fields:
            for field in fields:
                embed.add_field(
                    name=field.get("name", ""),
                    value=field.get("value", ""),
                    inline=field.get("inline", False)
                )
        
        return embed
    
    def ticket_embed(self, ticket_type: str, user: discord.Member, details: Dict[str, str]) -> discord.Embed:
        """
        Create a standardized ticket embed.
        
        Args:
            ticket_type: Type of ticket
            user: User who created the ticket
            details: Ticket details
            
        Returns:
            Formatted ticket embed
        """
        title_map = {
            "general": "General Inquiry Submitted!",
            "support": "Customer Support Ticket Created!",
            "collab": "Collaboration Inquiry Submitted!",
            "feedback": "Feedback/Report Submitted!"
        }
        
        description = f"Thank you {user.mention} for your {ticket_type.lower()} inquiry. Our team will review your request and get back to you shortly."
        
        embed = self.build(
            title=title_map.get(ticket_type, "Ticket Created!"),
            description=description,
            color_type="default",
            footer={
                "text": "We appreciate your patience.",
                "icon_url": user.guild.icon.url if user.guild.icon else None
            },
            image=self.config.get("tickets.embed_image")
        )
        
        # Format the details in a clean way
        details_text = "\n".join([f"> **{k}:** {v}" for k, v in details.items()])
        embed.add_field(name="Inquiry Details:", value=details_text, inline=False)
        
        return embed
    
    def error_embed(self, title: str, description: str) -> discord.Embed:
        """
        Create a standardized error embed.
        
        Args:
            title: Error title
            description: Error description
            
        Returns:
            Formatted error embed
        """
        return self.build(
            title=f"❌ {title}",
            description=description,
            color_type="error"
        )
    
    def success_embed(self, title: str, description: str) -> discord.Embed:
        """
        Create a standardized success embed.
        
        Args:
            title: Success title
            description: Success description
            
        Returns:
            Formatted success embed
        """
        return self.build(
            title=f"✅ {title}",
            description=description,
            color_type="success"
        )
    
    def info_embed(self, title: str, description: str) -> discord.Embed:
        """
        Create a standardized info embed.
        
        Args:
            title: Info title
            description: Info description
            
        Returns:
            Formatted info embed
        """
        return self.build(
            title=f"ℹ️ {title}",
            description=description,
            color_type="info"
        )