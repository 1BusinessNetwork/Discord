# utils/permissions.py

import discord
from discord import app_commands
from discord.ext import commands
from typing import Callable, TypeVar, ParamSpec, Awaitable, cast, Optional, Union

T = TypeVar('T')
P = ParamSpec('P')

class PermissionChecker:
    """
    Utility class for permission checking decorators.
    Provides methods to check permissions for slash commands and regular commands.
    """
    
    @staticmethod
    def is_owner():
        """
        Check if the user is the bot owner.
        
        Returns:
            A check function for commands/app_commands
        """
        async def predicate(ctx: Union[commands.Context, discord.Interaction]) -> bool:
            if isinstance(ctx, discord.Interaction):
                bot = ctx.client
                result = await bot.is_owner(ctx.user)
                if not result:
                    await ctx.response.send_message("Only the bot owner can use this command!", ephemeral=True)
                return result
            else:
                return await ctx.bot.is_owner(ctx.author)
        
        return commands.check(predicate)
    
    @staticmethod
    def is_admin():
        """
        Check if the user has admin permissions.
        
        Returns:
            A check function for commands/app_commands
        """
        async def predicate(interaction: discord.Interaction) -> bool:
            if not interaction.user.guild_permissions.administrator:
                await interaction.response.send_message("You don't have permission to use this command!", ephemeral=True)
                return False
            return True
        
        return app_commands.check(predicate)
    
    @staticmethod
    def has_role(role_id: int):
        """
        Check if the user has a specific role.
        
        Args:
            role_id: ID of the role to check for
            
        Returns:
            A check function for commands/app_commands
        """
        async def predicate(ctx: Union[commands.Context, discord.Interaction]) -> bool:
            if isinstance(ctx, discord.Interaction):
                user = ctx.user
                if not isinstance(user, discord.Member):
                    await ctx.response.send_message("This command can only be used in a server!", ephemeral=True)
                    return False
                
                role = ctx.guild.get_role(role_id)
                if not role:
                    await ctx.response.send_message("Role configuration error. Please contact an administrator.", ephemeral=True)
                    return False
                
                if role not in user.roles:
                    await ctx.response.send_message(f"You need the {role.name} role to use this command!", ephemeral=True)
                    return False
                
                return True
            else:
                if not ctx.guild:
                    await ctx.send("This command can only be used in a server!")
                    return False
                
                role = ctx.guild.get_role(role_id)
                if not role:
                    await ctx.send("Role configuration error. Please contact an administrator.")
                    return False
                
                if role not in ctx.author.roles:
                    await ctx.send(f"You need the {role.name} role to use this command!")
                    return False
                
                return True
        
        # Determine which decorator to use based on the context
        def decorator(func):
            if hasattr(func, "__interaction_check__"):
                return app_commands.check(predicate)(func)
            else:
                return commands.check(predicate)(func)
        
        return decorator
    
    @staticmethod
    def check_ticket():
        """
        Check if the command is used in a ticket channel.
        
        Returns:
            A check function for commands
        """
        async def predicate(ctx: commands.Context) -> bool:
            if ctx.channel.topic and "ticket" in ctx.channel.topic.lower():
                return True
            if ctx.command and ctx.command.name == 'help':
                return True
            
            await ctx.reply("This command can only be used in a ticket channel!", delete_after=9)
            return False
        
        return commands.check(predicate)
    
    @staticmethod
    def in_guild():
        """
        Check if the command is used in a guild.
        
        Returns:
            A check function for commands/app_commands
        """
        async def predicate(ctx: Union[commands.Context, discord.Interaction]) -> bool:
            if isinstance(ctx, discord.Interaction):
                if not ctx.guild:
                    await ctx.response.send_message("This command can only be used in a server!", ephemeral=True)
                    return False
                return True
            else:
                if not ctx.guild:
                    await ctx.send("This command can only be used in a server!")
                    return False
                return True
        
        def decorator(func):
            if hasattr(func, "__interaction_check__"):
                return app_commands.check(predicate)(func)
            else:
                return commands.check(predicate)(func)
        
        return decorator