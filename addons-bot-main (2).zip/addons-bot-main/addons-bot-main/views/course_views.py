# views/course_views.py

import discord
import re
from discord.ui import View, Select, Button
from typing import List, Dict, Any, Optional

class CourseModuleView(View):
    """View with a button to access module lessons."""
    
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(label="Access Content", style=discord.ButtonStyle.primary, custom_id="module_button")
    async def module_button(self, interaction: discord.Interaction, button: Button):
        """Handle button click to access module content."""
        # Extract module number from the message
        embed = interaction.message.embeds[0]
        footer_text = embed.footer.text
        
        module_match = re.search(r"module\s+(\d+)", footer_text, re.IGNORECASE)
        if not module_match:
            await interaction.response.send_message("Module information not found!", ephemeral=True)
            return
        
        module_number = int(module_match.group(1))
        
        # Create options for module lessons
        options = self._create_lesson_options(interaction.client, module_number)
        
        if not options:
            await interaction.response.send_message(
                "No lessons found for this module. Please check back later!",
                ephemeral=True
            )
            return
        
        # Create select menu
        select = LessonSelect(options, module_number)
        
        # Create view
        view = View(timeout=120)
        view.add_item(select)
        
        await interaction.response.send_message(
            "Please select a lesson to view:",
            view=view,
            ephemeral=True
        )
    
    def _create_lesson_options(self, bot, module_number: int) -> List[discord.SelectOption]:
        """Create select options for module lessons."""
        options = []
        
        # Get lessons data
        lessons = bot.config.get("courses.lessons", {})
        
        # Filter lessons for this module
        module_prefix = f"{module_number:02d}"
        module_lessons = {
            k: v for k, v in lessons.items() 
            if k.startswith(module_prefix)
        }
        
        # Add options for each lesson
        for lesson_key, lesson_data in sorted(module_lessons.items()):
            lesson_number = int(lesson_key[2:])
            title = lesson_data.get("title", f"Lesson {lesson_number}")
            
            options.append(
                discord.SelectOption(
                    label=f"Lesson {lesson_number}",
                    value=lesson_key,
                    description=title[:50] + "..." if len(title) > 50 else title
                )
            )
        
        return options


class LessonSelect(Select):
    """Select menu for choosing a lesson."""
    
    def __init__(self, options: List[discord.SelectOption], module_number: int):
        super().__init__(
            placeholder="Select a lesson",
            min_values=1,
            max_values=1,
            options=options
        )
        self.module_number = module_number
    
    async def callback(self, interaction: discord.Interaction):
        """Handle lesson selection."""
        lesson_key = self.values[0]
        
        # Get lesson data
        lessons = interaction.client.config.get("courses.lessons", {})
        lesson_data = lessons.get(lesson_key)
        
        if not lesson_data:
            await interaction.response.send_message(
                "Lesson not found! Please try again.",
                ephemeral=True
            )
            return
        
        # Create embed
        lesson_number = int(lesson_key[2:])
        title = lesson_data.get("title", f"Lesson {lesson_number}")
        content = lesson_data.get("content", "No content available.")
        video_url = lesson_data.get("video_url")
        
        embed = discord.Embed(
            title=f"Module {self.module_number} - {title}",
            description=content,
            color=interaction.client.config.get("server.color_theme")
        )
        
        # Prepare response
        response_content = ""
        if video_url:
            response_content = video_url
        
        # Send lesson
        await interaction.response.send_message(
            content=response_content,
            embed=embed,
            ephemeral=True
        )