# views/verification_views.py

import discord
from discord.ui import View, Button, Modal, TextInput
from discord import ButtonStyle, TextStyle
import asyncio
from utils.captcha import CaptchaGenerator

class VerificationButton(View):
    """
    View with verification button for users to verify their account.
    """
    
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(label="Verify Account", style=ButtonStyle.primary, custom_id="verification_button")
    async def verify_button(self, interaction: discord.Interaction, button: Button):
        """Handle verification button click."""
        # Get the role ID from config
        role_id = interaction.client.config.get("server.member_role_id")
        role = interaction.guild.get_role(role_id)
        
        if not role:
            await interaction.response.send_message(
                "Verification role not found! Please contact an administrator.",
                ephemeral=True
            )
            return
        
        # Check if user already has the role
        if role in interaction.user.roles:
            await interaction.response.send_message(
                "You are already verified!",
                ephemeral=True
            )
            return
        
        # Generate a captcha
        captcha_code = CaptchaGenerator.generate_code()
        captcha_image = CaptchaGenerator.generate_image(captcha_code)
        
        # Save captcha data for this user
        bot = interaction.client
        bot.active_captchas[interaction.user.id] = {
            "code": captcha_code,
            "timestamp": discord.utils.utcnow()
        }
        
        # Create embed
        embed = discord.Embed(
            title="Account Verification",
            color=bot.config.get("server.color_theme")
        )
        embed.set_footer(text="Enter the 3-character code shown above • You have 60 seconds")
        
        # Create verification view
        verify_view = CaptchaVerifyView(captcha_code, role_id)
        
        # Send the captcha
        await interaction.response.send_message(
            content="Please look at the captcha image below and click the 'Enter Code' button to proceed:",
            embed=embed,
            file=discord.File(fp=captcha_image, filename="captcha.png"),
            view=verify_view,
            ephemeral=True
        )
        
        # Schedule cleanup of captcha data
        bot.loop.create_task(self._cleanup_captcha(interaction.user.id))
    
    async def _cleanup_captcha(self, user_id, timeout=300):
        """Remove captcha data after timeout."""
        await asyncio.sleep(timeout)
        
        bot = self.client if hasattr(self, "client") else None
        if bot and user_id in bot.active_captchas:
            del bot.active_captchas[user_id]


class CaptchaVerifyView(View):
    """View with button to enter captcha verification code."""
    
    def __init__(self, captcha_code, role_id):
        super().__init__(timeout=60)
        self.captcha_code = captcha_code
        self.role_id = role_id
    
    @discord.ui.button(label="Enter Code", style=ButtonStyle.success)
    async def enter_code_button(self, interaction: discord.Interaction, button: Button):
        """Handle click on the button to enter captcha code."""
        # Show modal to enter code
        modal = CaptchaInputModal(self.captcha_code, self.role_id)
        await interaction.response.send_modal(modal)


class CaptchaInputModal(Modal):
    """Modal for entering captcha verification code."""
    
    def __init__(self, captcha_code, role_id):
        super().__init__(title="Enter Verification Code")
        self.captcha_code = captcha_code
        self.role_id = role_id
        
        self.captcha_input = TextInput(
            label="Enter the 3-character code from the image",
            placeholder="Type exactly what you see (case sensitive)",
            required=True,
            max_length=3,
            min_length=3
        )
        
        self.add_item(self.captcha_input)
    
    async def on_submit(self, interaction: discord.Interaction):
        """Handle verification code submission."""
        user_input = self.captcha_input.value.strip()
        
        if user_input == self.captcha_code:
            # Success! Assign the role
            role = interaction.guild.get_role(self.role_id)
            if not role:
                await interaction.response.send_message(
                    "Error: Verification role not found. Please contact an administrator.",
                    ephemeral=True
                )
                return
            
            try:
                await interaction.user.add_roles(role)
                
                success_embed = discord.Embed(
                    title="✅ Verification Successful",
                    description=f"You have been successfully verified and received the {role.name} role!",
                    color=discord.Color.green()
                )
                await interaction.response.send_message(embed=success_embed, ephemeral=True)
                
                # Clean up
                bot = interaction.client
                if interaction.user.id in bot.active_captchas:
                    del bot.active_captchas[interaction.user.id]
                
                # Log the verification
                bot.logger.info(f"User {interaction.user} ({interaction.user.id}) verified successfully")
                
            except discord.Forbidden:
                await interaction.response.send_message(
                    "❌ I don't have permission to assign roles. Please contact an administrator.",
                    ephemeral=True
                )
            except Exception as e:
                await interaction.response.send_message(
                    f"❌ An error occurred: {str(e)}",
                    ephemeral=True
                )
        else:
            # Failed verification
            error_embed = discord.Embed(
                title="❌ Verification Failed",
                description="The code you entered doesn't match. Please try again by clicking the verification button.",
                color=discord.Color.red()
            )
            await interaction.response.send_message(embed=error_embed, ephemeral=True)