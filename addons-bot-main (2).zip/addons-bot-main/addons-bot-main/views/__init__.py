# views/__init__.py

"""
Views package containing all UI components.
"""
async def setup(bot):
    pass  # Nessuna azione specifica richiesta per questo pacchetto