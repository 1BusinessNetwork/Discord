
import discord

VERIFIED_ROLE_ID = 812021501938368554
CTA_LINK_URL = "https://discord.com/channels/800484865774190662/1348820604266221620"  # Replace with your actual link

class VerifyFormModal(discord.ui.Modal, title="Verify to Access Business Network"):
    name = discord.ui.TextInput(label="Your Full Name", placeholder="e.g., John Doe", required=True)
    email = discord.ui.TextInput(label="Email Address", placeholder="e.g., you@example.com", required=True)
    goal = discord.ui.TextInput(label="What do you want to achieve here?", style=discord.TextStyle.paragraph, required=True)

    def __init__(self, bot, user):
        super().__init__()
        self.bot = bot
        self.user = user

    async def on_submit(self, interaction: discord.Interaction):
        verified_role = interaction.guild.get_role(VERIFIED_ROLE_ID)
        if verified_role:
            try:
                await interaction.user.add_roles(verified_role, reason="User verified via form")
            except discord.Forbidden:
                await interaction.response.send_message("⚠️ I don’t have permission to assign roles!", ephemeral=True)
                return

        await interaction.response.send_message(
            f"✅ Thank you {self.user.mention}! You’re verified. Let’s get started!",
            ephemeral=True
        )
        await send_cta_panel(interaction.channel, self.user)

        sheet_channel_id = 889384501380284437
        sheet_channel = interaction.guild.get_channel(sheet_channel_id)
        if sheet_channel:
            embed = discord.Embed(
                title="📝 New Verification Submitted",
                description=f"**User:** {self.user.mention} (`{self.user.id}`)",
                color=discord.Color.green()
            )
            embed.add_field(name="Name", value=self.name.value, inline=False)
            embed.add_field(name="Email", value=self.email.value, inline=False)
            embed.add_field(name="Goal", value=self.goal.value, inline=False)
            await sheet_channel.send(embed=embed)

class VerifyMeButton(discord.ui.View):
    def __init__(self, bot):
        super().__init__(timeout=None)
        self.bot = bot

    @discord.ui.button(label="✅ Verify Me", style=discord.ButtonStyle.success, custom_id="verify_me_btn")
    async def verify_me(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_modal(VerifyFormModal(self.bot, interaction.user))

class CTAPanelView(discord.ui.View):
    def __init__(self):
        super().__init__(timeout=None)
        link_button = discord.ui.Button(label="✅ Get Services", style=discord.ButtonStyle.link, url=CTA_LINK_URL)
        self.add_item(link_button)

    @discord.ui.button(label="🔵 Learn", style=discord.ButtonStyle.primary, custom_id="cta_learn")
    async def learn_button(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("📘 __Check out our learning resources in:__\n\n https://discord.com/channels/800484865774190662/1259324076250365952 = $100 Value for Free! (Scale to $15k/m) \n https://discord.com/channels/800484865774190662/1348750453596487763 = ***$1,000+ Value for a few dollars.***", ephemeral=False)

    @discord.ui.button(label="🧠 Talk to a Human", style=discord.ButtonStyle.secondary, custom_id="cta_human")
    async def talk_to_human(self, interaction: discord.Interaction, button: discord.ui.Button):
        await interaction.response.send_message("💬 A <@&918222200409038868> member will contact you in this channel shortly!\n https://discord.com/channels/800484865774190662/1174724639839236156 and introduce yourself to the network.\n https://discord.com/channels/800484865774190662/1054554026756296724 please keep self-promotion to the forums. \n https://discord.com/channels/800484865774190662/1054479138645344337 Talk with others in the Lounge. ", ephemeral=False)

async def send_cta_panel(channel, user):
    embed = discord.Embed(
        title="✅ You’re In!",
        description=f"""Welcome {user.mention}!
      

What would you like to do next?
- 🔵 **Learn**: Review guides and tips
- 🧠 **Talk to a Human**: Connect with support
- ✅ **Get Services**: Get accelerated right away""",
        color=discord.Color.teal()
    )
    await channel.send(embed=embed, view=CTAPanelView())
