# views/ticket_views.py

import discord
import re
import asyncio
import logging
from typing import Optional, Union, Dict, List
from discord.ui import View, Button, Modal, TextInput, Select
from discord import ButtonStyle, TextStyle

# Configure logger
logger = logging.getLogger(__name__)

# Utility functions
def get_ticket_owner(channel, guild):
    """Extract ticket owner from channel topic.
    
    Args:
        channel: The discord channel
        guild: The discord guild
        
    Returns:
        The member object of the ticket owner or None if not found
    """
    if not channel.topic:
        return None
    
    matches = re.findall(r"<@!?(\d+)>", channel.topic)
    if not matches:
        return None
    
    try:
        user_id = int(matches[0])
        return guild.get_member(user_id)
    except (ValueError, IndexError):
        return None

def get_config_value(client, key: str, default=None):
    """Safely retrieve a configuration value with a default fallback.
    
    Args:
        client: The discord client
        key: The configuration key to retrieve
        default: The default value to return if key is not found
        
    Returns:
        The configuration value or default if not found
    """
    try:
        return client.config.get(key, default)
    except (AttributeError, KeyError):
        return default

async def create_transcript(client, channel, deleted_by=None):
    """Create a transcript of the channel.
    
    Args:
        client: The discord client
        channel: The channel to create a transcript for
        deleted_by: The user who deleted the channel (optional)
        
    Returns:
        True if successful, False otherwise
    """
    try:
        await client.transcript_manager.log_transcript(
            channel=channel,
            deleted_by=deleted_by
        )
        return True
    except Exception as e:
        logger.error(f"Error creating transcript: {str(e)}")
        return False

class TicketCloseButton(View):
    """View with buttons to close or delete a ticket."""
    
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(label="Close", style=ButtonStyle.gray, custom_id="close_ticket_button")
    async def close_button(self, interaction: discord.Interaction, button: Button):
        """Handle ticket close button click."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        
        # Check if user has staff role
        staff_role_id = get_config_value(interaction.client, "server.staff_role_id")
        staff_role = discord.utils.get(interaction.guild.roles, id=staff_role_id)
        
        if not staff_role or staff_role not in interaction.user.roles:
            await interaction.followup.send("You don't have permission to close this ticket!", ephemeral=True)
            return
        
        # Check if this is an onboarding channel
        is_onboarding = interaction.channel.topic and "onboard" in interaction.channel.topic.lower()
        
        # Ask for confirmation with appropriate message
        if is_onboarding:
            embed = discord.Embed(
                description=f"{interaction.user.mention}, Are you sure you want to close this onboarding channel?\n\nThe channel will be deleted.",
                color=discord.Color.gold()
            )
        else:
            embed = discord.Embed(
                description=f"{interaction.user.mention}, Are you sure you want to close this ticket?\n\nThe channel will be locked.",
                color=discord.Color.gold()
            )
        
        await interaction.followup.send(embed=embed, view=TicketCloseConfirmation(), ephemeral=True)
    
    @discord.ui.button(label="Delete", style=ButtonStyle.red, custom_id="delete_ticket_button")
    async def delete_button(self, interaction: discord.Interaction, button: Button):
        """Handle ticket delete button click."""
        await interaction.response.defer(ephemeral=True)
        
        # Check if user has staff role
        staff_role_id = get_config_value(interaction.client, "server.staff_role_id")
        staff_role = discord.utils.get(interaction.guild.roles, id=staff_role_id)
        
        if not staff_role or staff_role not in interaction.user.roles:
            await interaction.followup.send("You don't have permission to delete this ticket!", ephemeral=True)
            return
        
        # Ask for confirmation
        await interaction.followup.send(
            "Do you really want to delete this ticket?",
            view=TicketDeleteConfirmation(),
            ephemeral=True
        )


class TicketCloseConfirmation(View):
    """Confirmation view for closing a ticket."""
    
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(label="Confirm", style=ButtonStyle.gray, custom_id="confirm_close_ticket")
    async def confirm_button(self, interaction: discord.Interaction, button: Button):
        """Handle confirmation of ticket closure."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        
        # Check if this is an onboarding channel
        is_onboarding = interaction.channel.topic and "onboard" in interaction.channel.topic.lower()
        
        # If it's an onboarding channel, handle it like a delete instead
        if is_onboarding:
            try:
                # Create transcript before eliminating
                success = await create_transcript(
                    interaction.client,
                    interaction.channel,
                    deleted_by=interaction.user
                )
                
                if success:
                    # Inform the user
                    await interaction.followup.send("Transcript created and closing onboarding channel...", ephemeral=True)
                    
                    # Send message in the channel
                    await interaction.channel.send(
                        embed=discord.Embed(
                            description=f"Onboarding channel was closed by: {interaction.user.mention} | {interaction.user.id} | {interaction.user.name}"
                        )
                    )
                    
                    # Wait briefly to ensure the message is sent
                    await asyncio.sleep(2)
                    
                    # Delete the channel
                    await interaction.channel.delete(reason=f"Onboarding channel closed by {interaction.user}")
                else:
                    await interaction.followup.send("Failed to create transcript, but proceeding with channel closure...", ephemeral=True)
                return
            except Exception as e:
                logger.error(f"Error closing onboarding channel: {str(e)}")
                await interaction.followup.send(f"Error closing onboarding channel: {str(e)}", ephemeral=True)
                return
        
        # Regular ticket closing logic for non-onboarding channels
        # Create embed for notification
        embed = discord.Embed(
            description=f"**Ticket Closed by {interaction.user.mention}**",
            color=0x000000
        )
        
        # Get ticket owner from channel topic
        ticket_owner = get_ticket_owner(interaction.channel, interaction.guild)
        
        if ticket_owner:
            # Check current permissions
            channel_overwrites = interaction.channel.overwrites_for(ticket_owner)
            
            if channel_overwrites.read_messages or channel_overwrites.send_messages:
                # Remove permissions from ticket owner
                await interaction.channel.set_permissions(
                    ticket_owner,
                    read_messages=False,
                    send_messages=False
                )
                
                # Send notification
                await interaction.channel.send(embed=embed, view=TicketReopenDeleteView())
                await interaction.followup.send("Ticket closed successfully!", ephemeral=True)
            else:
                await interaction.followup.send("This ticket is already closed!", ephemeral=True)
        else:
            await interaction.followup.send("No ticket owner found in the topic!", ephemeral=True)
    
    @discord.ui.button(label="Cancel", style=ButtonStyle.gray, custom_id="cancel_close_ticket")
    async def cancel_button(self, interaction: discord.Interaction, button: Button):
        """Handle cancellation of ticket closure."""
        await interaction.response.defer(ephemeral=True)
        await interaction.delete_original_response()


class TicketDeleteConfirmation(View):
    """Confirmation view for deleting a ticket."""
    
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(label="Confirm", style=ButtonStyle.gray, custom_id="confirm_delete_ticket")
    async def confirm_button(self, interaction: discord.Interaction, button: Button):
        """Handle confirmation of ticket deletion."""
        await interaction.response.defer(ephemeral=True)
        
        # Log that the ticket is being deleted
        await interaction.followup.send("Deleting this ticket...", ephemeral=True)
        
        try:
            # Create deletion message in channel
            await interaction.channel.send(
                embed=discord.Embed(
                    description=f"Ticket was deleted by: {interaction.user.mention} | {interaction.user.id} | {interaction.user.name}"
                )
            )
            
            # Create transcript
            success = await create_transcript(
                interaction.client,
                interaction.channel,
                deleted_by=interaction.user
            )
            
            if not success:
                await interaction.followup.send("Warning: Failed to create transcript before deletion.", ephemeral=True)
            
            # Wait briefly to ensure the message is sent and transcript is created
            await asyncio.sleep(1)
            
            # Delete the channel
            await interaction.channel.delete(reason=f"Ticket deleted by {interaction.user}")
        except Exception as e:
            logger.error(f"Error deleting ticket: {str(e)}")
            await interaction.followup.send(f"An error occurred while deleting the ticket: {str(e)}", ephemeral=True)
    
    @discord.ui.button(label="Cancel", style=ButtonStyle.gray, custom_id="cancel_delete_ticket")
    async def cancel_button(self, interaction: discord.Interaction, button: Button):
        """Handle cancellation of ticket deletion."""
        await interaction.response.defer(ephemeral=True)
        try:
            await interaction.edit_original_response(
                content="Deletion of ticket has been cancelled!",
                view=None
            )
        except Exception as e:
            logger.error(f"Error canceling deletion: {str(e)}")
            await interaction.followup.send("Deletion of ticket has been cancelled!", ephemeral=True)


class TicketReopenDeleteView(View):
    """View with options to reopen or delete a closed ticket."""
    
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(label="Delete", style=ButtonStyle.red, custom_id="delete_closed_ticket")
    async def delete_button(self, interaction: discord.Interaction, button: Button):
        """Handle deletion of a closed ticket."""
        await interaction.response.defer(ephemeral=True)
        
        # Check if user has staff role
        staff_role_id = get_config_value(interaction.client, "server.staff_role_id")
        staff_role = discord.utils.get(interaction.guild.roles, id=staff_role_id)
        
        if not staff_role or staff_role not in interaction.user.roles:
            await interaction.followup.send("You don't have permission to delete this ticket!", ephemeral=True)
            return
        
        # Ask for confirmation
        await interaction.followup.send(
            "Do you really want to delete this ticket?",
            view=TicketDeleteConfirmation(),
            ephemeral=True
        )
    
    @discord.ui.button(label="Reopen", style=ButtonStyle.gray, custom_id="reopen_ticket")
    async def reopen_button(self, interaction: discord.Interaction, button: Button):
        """Handle reopening of a closed ticket."""
        await interaction.response.defer(ephemeral=True, thinking=True)
        
        # Check if user has staff role
        staff_role_id = get_config_value(interaction.client, "server.staff_role_id")
        staff_role = discord.utils.get(interaction.guild.roles, id=staff_role_id)
        
        if not staff_role or staff_role not in interaction.user.roles:
            await interaction.followup.send("You don't have permission to reopen this ticket!", ephemeral=True)
            return
        
        # Try to find the "Ticket Closed" message
        try:
            message_found = False
            async for message in interaction.channel.history(limit=10):
                if message.embeds and "Ticket Closed" in message.embeds[0].description:
                    message_found = True
                    # Create a new embed to indicate the ticket is reopened
                    closure_embed = message.embeds[0]
                    reopen_embed = discord.Embed(
                        description=f"Ticket has been reopened by {interaction.user.mention}",
                        color=0x00FF00
                    )
                    
                    # Edit the original message
                    await message.edit(embeds=[closure_embed, reopen_embed], view=None)
                    break
                    
            if not message_found:
                logger.info("Could not find closure message to edit")
        except Exception as e:
            # Proceed even if we can't find/edit the message
            logger.error(f"Error finding/editing closure message: {str(e)}")
        
        # Get ticket owner from channel topic
        ticket_owner = get_ticket_owner(interaction.channel, interaction.guild)
        
        if ticket_owner:
            # Check current permissions
            overwrites = interaction.channel.overwrites_for(ticket_owner)
            
            if overwrites.read_messages is False or overwrites.send_messages is False:
                # Restore permissions
                await interaction.channel.set_permissions(
                    ticket_owner,
                    read_messages=True,
                    send_messages=True
                )
                
                # Send notification
                reopen_embed = discord.Embed(
                    description=f"Ticket reopened by {interaction.user.mention}",
                    color=0x00FF00
                )
                await interaction.channel.send(embed=reopen_embed)
                await interaction.followup.send("Ticket reopened successfully!", ephemeral=True)
            else:
                await interaction.followup.send("Ticket is already open!", ephemeral=True)
        else:
            await interaction.followup.send("No ticket owner found in the topic!", ephemeral=True)


class TicketPanelView(View):
    """View for the main ticket panel in a server."""
    
    def __init__(self):
        super().__init__(timeout=None)
    
    @discord.ui.button(label="Create Ticket", style=ButtonStyle.primary, custom_id="create_ticket_button")
    async def create_ticket_button(self, interaction: discord.Interaction, button: Button):
        """Handle ticket creation button click."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        
        # Check if user already has too many tickets
        guild = interaction.guild
        user_mention = interaction.user.mention
        user_ticket_channels = []
        
        for channel in guild.text_channels:
            if channel.topic and user_mention in channel.topic and "ticket" in channel.topic.lower():
                user_ticket_channels.append(channel.mention)
        
        # Limit to 2 active tickets per user
        if len(user_ticket_channels) >= 2:  # Changed from > 2 to >= 2 for clarity
            await interaction.followup.send(
                f"You cannot create more than two tickets. You have already created tickets in: {', '.join(user_ticket_channels)}",
                ephemeral=True
            )
            return
        
        # Show ticket type selection
        select = self._create_ticket_type_select()
        view = View()
        view.add_item(select)
        
        await interaction.followup.send(
            "Please select the type of ticket you would like to create:",
            view=view,
            ephemeral=True
        )
    
    def _create_ticket_type_select(self):
        """Create a select menu for ticket types."""
        select = Select(
            placeholder="Select ticket type",
            options=[
                discord.SelectOption(
                    label="General Inquiry",
                    emoji="📩",
                    value="general",
                    description="General questions and inquiries"
                ),
                discord.SelectOption(
                    label="Customer Support",
                    emoji="🛠️",
                    value="support",
                    description="Help with products or services"
                ),
                discord.SelectOption(
                    label="Collaboration/Partnership",
                    emoji="🤝",
                    value="collab",
                    description="Business partnership inquiries"
                ),
                discord.SelectOption(
                    label="Feedback/Report",
                    emoji="📝",
                    value="feedback",
                    description="Provide feedback or report issues"
                )
            ]
        )
        
        select.callback = self.ticket_type_callback
        return select
    
    async def ticket_type_callback(self, interaction: discord.Interaction):
        """Handle ticket type selection."""
        try:
            ticket_type = interaction.data["values"][0]
        except (KeyError, IndexError):
            await interaction.response.send_message("An error occurred selecting ticket type. Please try again.", ephemeral=True)
            return
        
        # Create appropriate modal based on ticket type
        if ticket_type == "general":
            modal = GeneralInquiryModal()
        elif ticket_type == "support":
            modal = CustomerSupportModal()
        elif ticket_type == "collab":
            # For collab, show a subcategory selection
            await self._show_collab_subcategories(interaction)
            return
        elif ticket_type == "feedback":
            # For feedback, show a subcategory selection
            await self._show_feedback_subcategories(interaction)
            return
        else:
            await interaction.response.send_message("Invalid ticket type selected!", ephemeral=True)
            return
        
        await interaction.response.send_modal(modal)
    
    async def _show_collab_subcategories(self, interaction: discord.Interaction):
        """Show subcategory selection for collaboration tickets."""
        select = Select(
            placeholder="Select collaboration type",
            options=[
                discord.SelectOption(label="Sponsorship", value="Sponsorship"),
                discord.SelectOption(label="Affiliate", value="Affiliate"),
                discord.SelectOption(label="Partnership", value="Partnership"),
                discord.SelectOption(label="Other", value="Other")
            ]
        )
        
        async def collab_subtype_callback(interaction: discord.Interaction):
            try:
                subtype = interaction.data["values"][0]
                modal = CollaborationModal(subtype)
                await interaction.response.send_modal(modal)
            except (KeyError, IndexError, Exception) as e:
                logger.error(f"Error in collab_subtype_callback: {str(e)}")
                await interaction.response.send_message("An error occurred. Please try again.", ephemeral=True)
        
        select.callback = collab_subtype_callback
        
        view = View()
        view.add_item(select)
        
        try:
            await interaction.response.edit_message(
                content="Please select the type of collaboration you're interested in:",
                view=view
            )
        except Exception as e:
            logger.error(f"Error showing collab subcategories: {str(e)}")
            await interaction.followup.send("An error occurred. Please try creating your ticket again.", ephemeral=True)
    
    async def _show_feedback_subcategories(self, interaction: discord.Interaction):
        """Show subcategory selection for feedback tickets."""
        select = Select(
            placeholder="Select feedback type",
            options=[
                discord.SelectOption(label="Suggestion", value="Suggestion"),
                discord.SelectOption(label="Bug Report", value="Bug Report"),
                discord.SelectOption(label="Improvement", value="Improvement"),
                discord.SelectOption(label="Other", value="Other")
            ]
        )
        
        async def feedback_subtype_callback(interaction: discord.Interaction):
            try:
                subtype = interaction.data["values"][0]
                modal = FeedbackModal(subtype)
                await interaction.response.send_modal(modal)
            except (KeyError, IndexError, Exception) as e:
                logger.error(f"Error in feedback_subtype_callback: {str(e)}")
                await interaction.response.send_message("An error occurred. Please try again.", ephemeral=True)
        
        select.callback = feedback_subtype_callback
        
        view = View()
        view.add_item(select)
        
        try:
            await interaction.response.edit_message(
                content="Please select the type of feedback you'd like to provide:",
                view=view
            )
        except Exception as e:
            logger.error(f"Error showing feedback subcategories: {str(e)}")
            await interaction.followup.send("An error occurred. Please try creating your ticket again.", ephemeral=True)


# Helper function for creating ticket channels
async def create_ticket_channel(interaction, ticket_type, details, channel_name_prefix="ticket"):
    """Create a ticket channel with proper permissions and initial message.
    
    Args:
        interaction: The discord interaction
        ticket_type: The type of ticket
        details: Details to include in the embed
        channel_name_prefix: Prefix for the channel name
        
    Returns:
        The created channel or None if an error occurred
    """
    bot = interaction.client
    
    # Get category from config
    category_id_key = f"tickets.{ticket_type}_category_id"
    fallback_category_id_key = "tickets.general_category_id"
    
    category_id = get_config_value(bot, category_id_key)
    if not category_id:
        category_id = get_config_value(bot, fallback_category_id_key)
    
    category = interaction.guild.get_channel(category_id) if category_id else None
    
    if not category:
        await interaction.followup.send("Ticket category not found! Please contact an administrator.", ephemeral=True)
        return None
    
    # Get staff role for permissions
    staff_role_id = get_config_value(bot, "server.staff_role_id")
    staff_role = interaction.guild.get_role(staff_role_id)
    
    if not staff_role:
        await interaction.followup.send("Staff role not found! Please contact an administrator.", ephemeral=True)
        return None
    
    # Set up permissions
    overwrites = {
        interaction.guild.default_role: discord.PermissionOverwrite(view_channel=False),
        interaction.user: discord.PermissionOverwrite(
            view_channel=True,
            send_messages=True,
            read_message_history=True,
            attach_files=True,
            add_reactions=True
        ),
        staff_role: discord.PermissionOverwrite(
            view_channel=True,
            send_messages=True,
            read_message_history=True,
            attach_files=True,
            add_reactions=True
        )
    }
    
    # Create the ticket channel
    try:
        sanitized_name = re.sub(r'[^a-zA-Z0-9 ]', '', interaction.user.name).lower()
        channel_name = f"{sanitized_name}-{channel_name_prefix}"
        
        ticket_channel = await interaction.guild.create_text_channel(
            name=channel_name[:100],  # Discord has a limit on channel name length
            category=category,
            topic=f"ticket-{interaction.user.mention}-{ticket_type}",
            overwrites=overwrites
        )
        
        # Create the ticket embed
        embed = bot.embed_builder.ticket_embed(ticket_type, interaction.user, details)
        
        # Send the welcome message
        await ticket_channel.send(
            f"{interaction.user.mention}, Welcome!",
            embed=embed,
            view=TicketCloseButton()
        )
        
        # Log the ticket creation
        logger.info(
            f"{ticket_type.capitalize()} ticket created by {interaction.user} ({interaction.user.id}) - "
            f"Channel: {ticket_channel.name} ({ticket_channel.id})"
        )
        
        return ticket_channel
    except Exception as e:
        logger.error(f"Error creating ticket channel: {str(e)}")
        await interaction.followup.send(f"An error occurred while creating your ticket: {str(e)}", ephemeral=True)
        return None


# Helper function to get user email from database
async def get_user_email(bot, user_id):
    """Get user email from the database.
    
    Args:
        bot: The discord client
        user_id: The user ID to look up
        
    Returns:
        The user's email or "Not provided" if not found
    """
    email = "Not provided"  # Default value
    try:
        # Assuming there's a MongoDB collection with user emails
        mongo_client = bot.mongo_client
        db_name = get_config_value(bot, "database.database_name", "reelsbuilder")
        collection_name = get_config_value(bot, "database.collections.user_emails", "user_emails")
        
        db = mongo_client[db_name]
        collection = db[collection_name]
        
        user_data = collection.find_one({"user_id": user_id})
        if user_data and "email" in user_data:
            email = user_data["email"]
    except Exception as e:
        logger.error(f"Error fetching user email: {str(e)}")
    
    return email


class GeneralInquiryModal(Modal):
    """Modal for creating a general inquiry ticket."""
    
    def __init__(self):
        super().__init__(title="General Inquiry")
        
        self.message = TextInput(
            label="Message",
            placeholder="How can we assist you? Please provide any helpful details.",
            style=TextStyle.paragraph,
            required=True
        )
        
        self.add_item(self.message)
    
    async def on_submit(self, interaction: discord.Interaction):
        """Handle modal submission."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        
        bot = interaction.client
        
        # Get user email from database
        email = await get_user_email(bot, interaction.user.id)
        
        # Create ticket details
        details = {
            "Message": self.message.value,
            "Email": email
        }
        
        # Create the ticket channel
        ticket_channel = await create_ticket_channel(
            interaction=interaction,
            ticket_type="general",
            details=details
        )
        
        if ticket_channel:
            # Update details with channel mention
            details["Ticket Channel"] = ticket_channel.mention
            
            # Notify the user
            await interaction.followup.send(
                f"Your ticket has been created: {ticket_channel.mention}",
                ephemeral=True
            )


class CustomerSupportModal(Modal):
    """Modal for creating a customer support ticket."""
    
    def __init__(self):
        super().__init__(title="Customer Support")
        
        self.message = TextInput(
            label="Message (Required)",
            placeholder="Describe your issue in detail.",
            style=TextStyle.paragraph,
            required=True
        )
        
        self.order_id = TextInput(
            label="Order ID (If Applicable)",
            placeholder="Include your Order ID for faster assistance.",
            required=False
        )
        
        self.add_item(self.message)
        self.add_item(self.order_id)
    
    async def on_submit(self, interaction: discord.Interaction):
        """Handle modal submission."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        
        bot = interaction.client
        
        # Get user email from database
        email = await get_user_email(bot, interaction.user.id)
        
        # Create ticket details
        details = {
            "Message": self.message.value,
            "Order ID": self.order_id.value or "Not provided",
            "Email": email
        }
        
        # Create the ticket channel
        ticket_channel = await create_ticket_channel(
            interaction=interaction,
            ticket_type="support",
            details=details
        )
        
        if ticket_channel:
            # Update details with channel mention
            details["Ticket Channel"] = ticket_channel.mention
            
            # Notify the user
            await interaction.followup.send(
                f"Your support ticket has been created: {ticket_channel.mention}",
                ephemeral=True
            )


class CollaborationModal(Modal):
    """Modal for creating a collaboration ticket."""
    
    def __init__(self, collab_type: str):
        super().__init__(title="Collaboration Inquiry")
        
        self.collab_type = collab_type
        
        self.message = TextInput(
            label="Message (Required)",
            placeholder="Describe your proposal or partnership opportunity in detail.",
            style=TextStyle.paragraph,
            required=True
        )
        
        self.company_name = TextInput(
            label="Company Name",
            placeholder="Enter the name of your company or organization.",
            required=True
        )
        
        self.website_link = TextInput(
            label="Website/Social Media (Optional)",
            placeholder="Your website or social media link.",
            required=False
        )
        
        self.add_item(self.message)
        self.add_item(self.company_name)
        self.add_item(self.website_link)
    
    async def on_submit(self, interaction: discord.Interaction):
        """Handle modal submission."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        
        bot = interaction.client
        
        # Get user email from database
        email = await get_user_email(bot, interaction.user.id)
        
        # Create ticket details
        details = {
            "Message": self.message.value,
            "Collaboration Type": self.collab_type,
            "Company Name": self.company_name.value,
            "Website/Social": self.website_link.value or "Not provided",
            "Email": email
        }
        
        # Create the ticket channel
        ticket_channel = await create_ticket_channel(
            interaction=interaction,
            ticket_type="collab",
            details=details,
            channel_name_prefix=f"{self.collab_type.lower()}-collab"
        )
        
        if ticket_channel:
            # Update details with channel mention
            details["Ticket Channel"] = ticket_channel.mention
            
            # Notify the user
            await interaction.followup.send(
                f"Your collaboration inquiry has been created: {ticket_channel.mention}",
                ephemeral=True
            )


class FeedbackModal(Modal):
    """Modal for creating a feedback ticket."""
    
    def __init__(self, feedback_type: str):
        super().__init__(title="Feedback | Report")
        
        self.feedback_type = feedback_type
        
        self.message = TextInput(
            label="Message (Required)",
            placeholder="Describe your feedback or issue in detail.",
            style=TextStyle.paragraph,
            required=True
        )
        
        self.add_item(self.message)
    
    async def on_submit(self, interaction: discord.Interaction):
        """Handle modal submission."""
        await interaction.response.defer(thinking=True, ephemeral=True)
        
        bot = interaction.client
        
        # Get user email from database
        email = await get_user_email(bot, interaction.user.id)
        
        # Create ticket details
        details = {
            "Message": self.message.value,
            "Feedback Type": self.feedback_type,
            "Email": email
        }
        
        # Create the ticket channel
        ticket_channel = await create_ticket_channel(
            interaction=interaction,
            ticket_type="feedback",
            details=details,
            channel_name_prefix=f"{self.feedback_type.lower()}-feedback"
        )
        
        if ticket_channel:
            # Update details with channel mention
            details["Ticket Channel"] = ticket_channel.mention
            
            # Notify the user
            await interaction.followup.send(
                f"Your feedback has been submitted: {ticket_channel.mention}",
                ephemeral=True
            )
