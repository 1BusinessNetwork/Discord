# app.py

from flask import Flask, send_from_directory, redirect, url_for
import os

class TranscriptServer:
    """
    Flask server for serving transcript files and assets.
    """
    
    def __init__(self, host="0.0.0.0", port=5000, debug=True):
        """
        Initialize the transcript server.
        
        Args:
            host: Host to bind to
            port: Port to listen on
            debug: Whether to enable debug mode
        """
        self.host = host
        self.port = port
        self.debug = debug
        
        # Use absolute path for Docker environment
        self.base_dir = "/app"
        
        # Initialize Flask app
        self.app = Flask(__name__)
        
        # Register routes
        self.register_routes()
    
    def register_routes(self):
        """Register Flask routes."""
        
        @self.app.route('/')
        def index():
            """Redirect to a default page or show an info message."""
            return """
            <html>
                <head>
                    <title>ReelsBuilder Transcript Server</title>
                    <style>
                        body {
                            font-family: Arial, sans-serif;
                            text-align: center;
                            margin-top: 100px;
                            background-color: #f5f5f5;
                        }
                        .container {
                            background-color: white;
                            border-radius: 10px;
                            box-shadow: 0 2px 10px rgba(0, 0, 0, 0.1);
                            padding: 30px;
                            max-width: 600px;
                            margin: 0 auto;
                        }
                        h1 {
                            color: #EC7110;
                        }
                    </style>
                </head>
                <body>
                    <div class="container">
                        <h1>ReelsBuilder Transcript Server</h1>
                        <p>This server hosts Discord channel transcripts. 
                        Use the direct link provided to access a specific transcript.</p>
                    </div>
                </body>
            </html>
            """
        
        @self.app.route('/transcripts/<path:filename>')
        def serve_transcripts(filename):
            """
            Serve files from 'transcripts' folder.
            
            Args:
                filename: File to serve
                
            Returns:
                File response
            """
            return send_from_directory(os.path.join(self.base_dir, "transcripts"), filename)
        
        @self.app.route('/transcripts/assets/<path:filename>')
        def serve_assets(filename):
            """
            Serve files from 'transcripts/assets' folder.
            
            Args:
                filename: File to serve
                
            Returns:
                File response
            """
            return send_from_directory(os.path.join(self.base_dir, "transcripts", "assets"), filename)
        
        @self.app.route('/data/asset/<path:filename>')
        def serve_data_assets(filename):
            """
            Alternative path for serving asset files.
            
            Args:
                filename: File to serve
                
            Returns:
                File response
            """
            return send_from_directory(os.path.join(self.base_dir, "transcripts", "assets"), filename)
    
    def run(self):
        """Run the Flask server."""
        self.app.run(host=self.host, port=self.port, debug=self.debug)

# Run the server if executed directly
if __name__ == '__main__':
    # Load configuration from file if exists
    try:
        import json
        config = {}
        
        if os.path.exists("/app/config/default_config.json"):
            with open("/app/config/default_config.json", "r") as f:
                config = json.load(f)
        
        # Extract web server configuration
        host = config.get("web", {}).get("host", "0.0.0.0")
        port = config.get("web", {}).get("port", 5000)
        debug = config.get("web", {}).get("debug", True)
        
    except Exception as e:
        print(f"Error loading configuration: {str(e)}")
        host = "0.0.0.0"
        port = 5000
        debug = True
    
    # Create and run server
    server = TranscriptServer(host=host, port=port, debug=debug)
    server.run()
