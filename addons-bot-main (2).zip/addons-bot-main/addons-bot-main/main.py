# main.py

import discord
import os
import asyncio
import json
import datetime
import traceback
from discord.ext import commands
from config.config import Config
from logs.logger import BotLogger
from utils.embed_builder import EmbedBuilder
from utils.transcript import TranscriptManager
from dotenv import load_dotenv
load_dotenv()



# Initial setup
intents = discord.Intents.all()

class ReelsBuilderBot(commands.Bot):
    """Main bot class with extended functionality."""
    
    def __init__(self):
        # Load configuration
        self.config = Config("config/default_config.json")
        
        # Initialize the bot with the prefix from config
        super().__init__(
            command_prefix=self.config.get("bot.prefix", "!r"),
            intents=intents,
            description=self.config.get("bot.description", "ReelsBuilder Discord Bot"),
            help_command=None
        )
        
        # Set up logger
        self.logger = BotLogger()
        self.logger.setup_discord_logger()
        
        # Initialize utilities
        self.embed_builder = EmbedBuilder(self)
        self.transcript_manager = TranscriptManager(self)
        
        # Active captchas storage
        self.active_captchas = {}
        
        # Track cogs loaded
        self.loaded_cogs = []
    
    async def setup_hook(self):
        """
        Called when the bot is starting up.
        Used to load cogs and perform initial setup.
        """
        self.logger.info("Bot is starting up...")
        
        # Load all cogs
        await self.load_all_cogs()
        
        # Schedule background tasks
        self.bg_task = self.loop.create_task(self.background_tasks())
        
        self.logger.info(f"Logged in as {self.user} (ID: {self.user.id})")
    
    async def on_ready(self):
        """Event called when the bot is ready."""
        self.logger.info("Bot is ready!")
        
        # Set bot status
        await self.change_presence(
            activity=discord.Activity(
                type=discord.ActivityType.watching, 
                name=".gg/reelsbuilder"
            )
        )
        
        # Log startup information
        guilds_count = len(self.guilds)
        users_count = sum(g.member_count for g in self.guilds)
        self.logger.info(f"Bot is in {guilds_count} guilds with access to {users_count} users")
    
    async def load_all_cogs(self):
        """Load all cogs from the cogs directory."""
        cogs_dir = "cogs"
        
        if not os.path.exists(cogs_dir):
            self.logger.warning("Cogs directory not found!")
            return
        
        # Get all python files in the cogs directory
        cog_files = [f for f in os.listdir(cogs_dir) if f.endswith(".py")]
        
        for cog_file in cog_files:
            # Extract cog name (remove .py extension)
            cog_name = cog_file[:-3]
            try:
                # Load the cog
                await self.load_extension(f"{cogs_dir}.{cog_name}")
                self.loaded_cogs.append(cog_name)
                self.logger.info(f"Loaded cog: {cog_name}")
            except Exception as e:
                self.logger.error(f"Failed to load cog {cog_name}: {str(e)}")
                traceback.print_exception(type(e), e, e.__traceback__)
    
    async def background_tasks(self):
        """Run background tasks periodically."""
        await self.wait_until_ready()
        
        while not self.is_closed():
            try:
                # Check for inactive tickets
                await self.check_inactive_tickets()
                
                # Check for temporary roles to remove
                await self.check_role_removals()
                
                # Wait for next cycle
                await asyncio.sleep(60)  # Run every minute
            except Exception as e:
                self.logger.error(f"Error in background tasks: {str(e)}")
                await asyncio.sleep(60)
    
    async def check_inactive_tickets(self):
        """Check for and handle inactive ticket channels."""
        now = datetime.datetime.now(datetime.timezone.utc)
        
        for guild in self.guilds:
            for channel in guild.text_channels:
                if not channel.topic or "ticket" not in channel.topic.lower():
                    continue
                
                # Get the last message
                last_message = None
                async for message in channel.history(limit=1):
                    last_message = message
                
                if not last_message:
                    continue
                
                is_onboarding = "onboard" in channel.topic.lower()
                
                # Determine timeout based on ticket type
                if "onboard-ticket-" in channel.topic.lower():
                    # Post-form ticket has 24h timeout
                    timeout = datetime.timedelta(hours=24)
                elif is_onboarding:
                    # Regular onboarding ticket has 30m timeout
                    timeout = datetime.timedelta(minutes=self.config.get("onboarding.timeout_minutes", 30))
                else:
                    # Regular tickets don't auto-close
                    continue
                
                time_difference = now - last_message.created_at
                
                if time_difference > timeout:
                    self.logger.info(f"Closing inactive ticket: {channel.name} ({channel.id})")
                    
                    # Save transcript
                    await self.transcript_manager.log_transcript(channel)
                    
                    # Remove verification role if it's an onboarding ticket
                    if is_onboarding:
                        ticket_owner = await self.transcript_manager.get_ticket_owner(channel)
                        if ticket_owner:
                            verification_role_id = self.config.get("server.verification_role_id")
                            if verification_role_id:
                                role = guild.get_role(verification_role_id)
                                if role and role in ticket_owner.roles:
                                    try:
                                        await ticket_owner.remove_roles(role)
                                        self.logger.info(f"Removed verification role from {ticket_owner} due to inactive onboarding")
                                    except discord.HTTPException as e:
                                        self.logger.error(f"Failed to remove verification role: {str(e)}")
                    
                    # Delete the channel
                    try:
                        await channel.delete(reason="Ticket timed out due to inactivity")
                    except discord.HTTPException as e:
                        self.logger.error(f"Failed to delete inactive ticket {channel.name}: {str(e)}")
    
    async def check_role_removals(self):
        """Check for temporary roles that need to be removed."""
        now = datetime.datetime.utcnow()
        
        # Load pending role removals
        pending_removals = {}
        try:
            if os.path.exists("data/storage/pending_roles.json"):
                with open("data/storage/pending_roles.json", "r") as f:
                    pending_removals = json.load(f)
        except Exception as e:
            self.logger.error(f"Error loading pending role removals: {str(e)}")
            return
        
        modified = False
        to_remove = []
        
        for member_id, roles in pending_removals.items():
            updated_roles = []
            
            for role_data in roles:
                removal_time = datetime.datetime.fromisoformat(role_data["removal_time"])
                role_id = role_data["role_id"]
                
                # Find the guild and role
                role = None
                guild = None
                member = None
                
                for g in self.guilds:
                    r = g.get_role(role_id)
                    if r:
                        role = r
                        guild = g
                        member = guild.get_member(int(member_id))
                        break
                
                if not guild or not role or not member:
                    continue
                
                if now >= removal_time:
                    if role in member.roles:
                        try:
                            await member.remove_roles(role)
                            self.logger.info(f"Removed temporary role {role.name} from {member}")
                            modified = True
                        except discord.HTTPException as e:
                            self.logger.error(f"Failed to remove role {role.name} from {member}: {str(e)}")
                            updated_roles.append(role_data)  # Keep in list to try again later
                else:
                    updated_roles.append(role_data)
            
            if updated_roles:
                pending_removals[member_id] = updated_roles
            else:
                to_remove.append(member_id)
        
        # Remove completed entries
        for member_id in to_remove:
            pending_removals.pop(member_id)
            modified = True
        
        # Save updated removals if modified
        if modified:
            try:
                os.makedirs("data/storage", exist_ok=True)
                with open("data/storage/pending_roles.json", "w") as f:
                    json.dump(pending_removals, f, indent=4)
            except Exception as e:
                self.logger.error(f"Error saving pending role removals: {str(e)}")
    
    async def on_command_error(self, ctx, error):
        """Global error handler for commands."""
        if isinstance(error, commands.CommandNotFound):
            return
        
        if isinstance(error, commands.MissingRequiredArgument):
            await ctx.send(f"Missing required argument: {error.param.name}")
            return
        
        if isinstance(error, commands.BadArgument):
            await ctx.send(f"Bad argument: {str(error)}")
            return
        
        if isinstance(error, commands.MissingPermissions):
            await ctx.send("You don't have permission to use this command!")
            return
        
        if isinstance(error, commands.BotMissingPermissions):
            await ctx.send(f"I don't have the required permissions: {', '.join(error.missing_permissions)}")
            return
        
        if isinstance(error, commands.CommandOnCooldown):
            await ctx.send(f"This command is on cooldown. Try again in {error.retry_after:.2f} seconds.")
            return
        
        if isinstance(error, commands.CheckFailure):
            # Generic check failure, already handled in the check itself
            return
        
        # Log unhandled errors
        self.logger.error(f"Unhandled command error in {ctx.command}: {str(error)}", exc_info=True)
        
        # Send a generic error message
        await ctx.send("An error occurred while executing the command. The error has been logged.")

# Run the bot
if __name__ == "__main__":
    # Create bot instance
    bot = ReelsBuilderBot()
    
    # Get token from environment variable
    token = os.getenv("DISCORD_TOKEN")
    
    if not token:
        print("Error: DISCORD_TOKEN environment variable not set!")
        exit(1)
    
    try:
        # Start the bot
        bot.run(token)
    except Exception as e:
        print(f"Error starting bot: {str(e)}")
        traceback.print_exception(type(e), e, e.__traceback__)
