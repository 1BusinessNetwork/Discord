# ReelsBuilder Addons Discord Bot

[![Python](https://img.shields.io/badge/python-3.11-blue.svg)](https://www.python.org/downloads/release/python-311/)
[![Discord.py](https://img.shields.io/badge/discord.py-2.4.0-blue.svg)](https://discordpy.readthedocs.io/en/stable/)
[![License](https://img.shields.io/badge/license-MIT-green.svg)](https://opensource.org/licenses/MIT)

A comprehensive Discord bot for the ReelsBuilder community. This bot provides member management, verification, ticketing, onboarding, and course management functionalities to enhance the Discord server experience.

![ReelsBuilder Logo](https://media.discordapp.net/attachments/1347896851130744852/1347896851352911973/ReelsBuilder_icon_classic.png?ex=67dd5044&is=67dbfec4&hm=aa261698329c3022110d0da4e1b721b79f1bf29c75a1846f20d7f337581e5c6b&=&format=webp&quality=lossless)

## Table of Contents

- [Features](#features)
- [Installation](#installation)
  - [Prerequisites](#prerequisites)
  - [Setup](#setup)
  - [Configuration](#configuration)
  - [Docker Deployment](#docker-deployment)
- [Commands](#commands)
  - [Administrative Commands](#administrative-commands)
  - [Verification Commands](#verification-commands)
  - [Ticket Commands](#ticket-commands)
  - [Role Management Commands](#role-management-commands)
  - [Utility Commands](#utility-commands)
  - [Course Management Commands](#course-management-commands)
- [Features in Detail](#features-in-detail)
  - [Verification System](#verification-system)
  - [Ticketing System](#ticketing-system)
  - [Onboarding System](#onboarding-system)
  - [Course Management](#course-management)
  - [Transcript System](#transcript-system)
- [File Structure](#file-structure)
- [Contributing](#contributing)
- [License](#license)
- [Contact](#contact)

## Features

- **Verification System**: CAPTCHA-based verification for new server members
- **Ticket System**: Support ticket management with categories, transcripts, and auto-closure
- **Onboarding Process**: Step-by-step member onboarding with automated channel creation
- **Role Management**: Temporary role assignment with automated expiration
- **Course Management**: VIP and free content management for educational material
- **Utility Commands**: Server information, user info, emoji management
- **Transcript System**: Logging and web-based viewing of ticket conversations

## Installation

### Prerequisites

- Python 3.11 or higher
- MongoDB database
- Discord Bot Token
- Docker (optional, for containerized deployment)

### Setup

1. Clone the repository:
   ```bash
   git clone https://github.com/yourusername/reelsbuilder-bot.git
   cd reelsbuilder-bot
   ```

2. Install the dependencies:
   ```bash
   pip install -r requirements.txt
   ```

3. Create required directories:
   ```bash
   mkdir -p data/logs data/storage transcripts/assets
   ```

4. Configure the bot (see [Configuration](#configuration))

5. Set your Discord bot token as an environment variable:
   ```bash
   export DISCORD_TOKEN=your_token_here
   ```

6. Run the bot:
   ```bash
   python main.py
   ```

### Configuration

The bot uses a JSON configuration file (`config/default_config.json`). The main configuration parameters are: 

```json
{
    "bot": {
        "prefix": "$",
        "description": "Business Network AI"
    },
    "server": {
        "color_theme": 15493648,
        "member_role_id": 81202150193836855, 
        "staff_role_id": 918222200409038868,
        "verification_role_id": 1094345255446397068
    },
    "database": {
        "mongo_uri": "your_mongodb_uri",
        "database_name": "cluster0",
        "collections": {
            "user_emails": "user_emails"
        }
    },
    "web": {
        "host": "0.0.0.0",
        "port": 5000,
        "debug": true,
        "base_url": "https://transcripts.reelsbuilder.ai"
    }
}
```

Key configuration sections:
- **bot**: Basic bot settings
- **server**: Server-specific settings and role IDs
- **emojis**: Custom emoji IDs used by the bot
- **tickets**: Ticket system configuration
- **onboarding**: Onboarding system settings
- **database**: MongoDB connection settings
- **web**: Transcript server configuration

### Docker Deployment

The bot can be deployed using Docker for easier setup and management:

1. Build the Docker image:
   ```bash
   docker build -t reelsbuilder-bot .
   ```

2. Run the container:
   ```bash
   docker run -d --name reelsbuilder-bot \
     -e DISCORD_TOKEN=yMTI2Mzk2MzcxMjQxOTc5NTE0Ng.GUasjU._NcGBVXyUSlGu8XaLzVwBoIF6TXpQwnP07YZughere \
     -v ./data:/app/data \
     -v ./transcripts:/app/transcripts \
     -p 5000:5000 \
     reelsbuilder-bot
   ```

Alternatively, use Docker Compose:

1. Configure your Discord token in the `.env` file:
   ```
   DISCORD_TOKEN=your_token_here
   ```

2. Start the services:
   ```bash
   docker-compose up -d
   ```

## Commands

The bot uses `!r` as its default command prefix. All commands can be used in both traditional format (`!rcommand`) and as slash commands.

### Administrative Commands

| Command | Description | Usage |
|---------|-------------|-------|
| `sync` | Syncs slash commands to Discord | `!rsync [guild_id]` |
| `contact_panel` | Creates a ticket panel in the current channel | `!rcontact_panel` |
| `verification_panel` | Creates a verification panel | `!rverification_panel` |
| `onboarding_panel` | Creates an onboarding panel | `!ronboarding_panel` |

### Verification Commands

| Command | Description | Usage |
|---------|-------------|-------|
| `verification_panel` | Creates a verification panel | `!rverification_panel` |
| `create_onboarding` | Creates an onboarding channel for a user | `!rcreate_onboarding @user` |
| `check_onboarding_channels` | Manually checks for inactive onboarding channels | `!rcheck_onboarding_channels` |

### Ticket Commands

| Command | Description | Usage |
|---------|-------------|-------|
| `delete_ticket` | Deletes the current ticket | `!rdelete_ticket` |
| `add_user` | Adds a user to the current ticket | `!radd_user @user` |
| `create_ticket` | Create a ticket for a specific user | `!rcreate_ticket @user` |

### Role Management Commands

| Command | Description | Usage |
|---------|-------------|-------|
| `temprole` | Assigns a temporary role to a member | `!rtemprole @user @role duration` |
| `roleinfo` | Displays information about a role | `!rroleinfo @role` |
| `rolemembers` | Lists all members with a specific role | `!rrolemembers @role` |

### Utility Commands

| Command | Description | Usage |
|---------|-------------|-------|
| `whois` | Displays detailed information about a user | `!rwhois [@user]` |
| `steal` | Adds custom emojis to the server from other servers | `!rsteal :emoji:` |
| `ping` | Checks the bot's latency | `!rping` |
| `info` | Displays information about the bot | `!rinfo` |

### Course Management Commands

| Command | Description | Usage |
|---------|-------------|-------|
| `course_preview` | Previews a course module | `!rcourse_preview <module_number>` |
| `module` | Creates a course module in the current channel | `!rmodule <module_number>` |
| `publish_courses` | Publishes all configured courses to a channel | `!rpublish_courses [channel_id]` |
| `set_vip_role` | Sets the VIP role for course access | `!rset_vip_role @role` |
| `set_free_lessons` | Sets which lessons in a module are free | `!rset_free_lessons <module_number> <lesson_numbers...>` |
| `reload_courses` | Reloads courses from the configuration file | `!rreload_courses` |

### Coupon Commands

| Command | Description | Usage |
|---------|-------------|-------|
| `coupon` | Sends a coupon code to a user through DM | `!rcoupon @user <code>` |

## Features in Detail

### Verification System

The verification system uses CAPTCHA to verify new members:

- **CAPTCHA Verification**: Users must solve a CAPTCHA to gain access to the server
- **Verification Role**: Temporary verification role assigned during the onboarding process
- **Automated Cleanup**: Removal of verification role after completing onboarding or timeout

To set up a verification panel:
```bash
!rverification_panel
```

### Ticketing System

The ticket system allows users to create support tickets:

- **Multiple Categories**: General Inquiry, Customer Support, Collaboration, Feedback
- **Form-Based Creation**: Detailed forms for each ticket type
- **Auto-Closing**: Inactive tickets are automatically closed
- **Transcripts**: Complete conversation logs saved for reference
- **Staff Management**: Staff commands for ticket handling

To set up a ticket panel:
```bash
!rcontact_panel
```

### Onboarding System

The onboarding system guides new members through a structured introduction:

- **Multi-Step Process**: Step-by-step guided onboarding
- **Private Channels**: Personalized onboarding experience
- **Automated Role Assignment**: Automatic role assignment upon completion
- **Timeout Protection**: Inactive onboarding channels are automatically cleaned up

To set up an onboarding panel:
```bash
!ronboarding_panel
```

### Course Management

The course system provides educational content with VIP/free access control:

- **Module-Based Courses**: Organized learning content
- **VIP Access Control**: Restricted content for premium members
- **Free Lessons**: Configurable free content for all members
- **File-Based Configuration**: Easy course content management

To set up a course module:
```bash
!rcourse_preview 1
```

### Transcript System

The transcript system provides logging and web-based viewing:

- **HTML Transcripts**: Complete conversation logs in HTML format
- **Web Server**: Built-in Flask server for viewing transcripts
- **Staff Access**: Protected access to conversation history
- **Automated Creation**: Transcripts created upon ticket closure

## File Structure

```
reelsbuilder-bot/
├── app.py                 # Flask web server for transcripts
├── main.py                # Main bot entry point
├── Dockerfile             # Docker configuration
├── docker-compose.yml     # Docker Compose configuration
├── requirements.txt       # Python dependencies
├── cogs/                  # Bot command modules
│   ├── admin.py           # Administrative commands
│   ├── coupon.py          # Coupon system
│   ├── courses.py         # Course management
│   ├── onboarding.py      # Onboarding system
│   ├── roles.py           # Role management
│   ├── tasks.py           # Background tasks
│   ├── tickets.py         # Ticket system
│   ├── utilities.py       # Utility commands
│   └── verification.py    # Verification system
├── config/                # Configuration files
│   ├── config.py          # Configuration manager
│   └── default_config.json # Default configuration
├── data/                  # Data storage
│   ├── logs/              # Log files
│   ├── storage/           # Persistent storage
│   └── templates/         # Message templates
├── logs/                  # Logging system
│   └── logger.py          # Logger implementation
├── utils/                 # Utility modules
│   ├── captcha.py         # CAPTCHA generator
│   ├── embed_builder.py   # Embed builder utility
│   ├── permissions.py     # Permission helpers
│   └── transcript.py      # Transcript manager
└── views/                 # UI components
    ├── course_views.py    # Course UI components
    ├── onboarding_views.py # Onboarding UI components
    ├── ticket_views.py    # Ticket UI components
    └── verification_views.py # Verification UI components
```

## Contributing

Contributions are welcome! Please feel free to submit a Pull Request.

1. Fork the repository
2. Create your feature branch (`git checkout -b feature/amazing-feature`)
3. Commit your changes (`git commit -m 'Add some amazing feature'`)
4. Push to the branch (`git push origin feature/amazing-feature`)
5. Open a Pull Request

## License

This project is licensed under the MIT License - see the LICENSE file for details.

## Contact

ReelsBuilder - [Website](https://reelsbuilder.ai/) - [Discord](https://discord.gg/reelsbuilder)

---

Made with ❤️ for the ReelsBuilder community
